#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("GpDoubleBuffer");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

/* ���� ���
int ex=100,ey=100;
void OnPaint(HDC hdc)
{
	Graphics G(hdc);
	SolidBrush S(Color(0,0,255));
	int x,y;

	for (x=0;x<=800;x+=50) {
		for (y=0;y<=600;y+=50) {
			G.FillRectangle(&S,x,y,40,40);
		}
	}

	SolidBrush S2(Color(128,255,0,0));
	G.FillEllipse(&S2,ex,ey,150,150);
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_KEYDOWN:
		switch (wParam) {
		case VK_LEFT:
			ex-=5;
			InvalidateRect(hWnd,NULL,TRUE);
			break;
		case VK_RIGHT:
			ex+=5;
			InvalidateRect(hWnd,NULL,TRUE);
			break;
		case VK_UP:
			ey-=5;
			InvalidateRect(hWnd,NULL,TRUE);
			break;
		case VK_DOWN:
			ey+=5;
			InvalidateRect(hWnd,NULL,TRUE);
			break;
		}
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}
//*/

//* ���� ���۸�
int ex=100,ey=100;
CachedBitmap *pCBit;

void UpdateScreen()
{
	Graphics G(hWndMain);
	RECT crt;
	GetClientRect(hWndMain,&crt);
	Bitmap *pBit=new Bitmap(crt.right,crt.bottom,&G);
	Graphics *memG=new Graphics(pBit);
	memG->FillRectangle(&SolidBrush(Color(255,255,255)),0,0,crt.right,crt.bottom);

	SolidBrush S(Color(0,0,255));
	int x,y;

	for (x=0;x<=800;x+=50) {
		for (y=0;y<=600;y+=50) {
			memG->FillRectangle(&S,x,y,40,40);
		}
	}

	SolidBrush S2(Color(128,255,0,0));
	memG->FillEllipse(&S2,ex,ey,150,150);
	if (pCBit) {
		delete pCBit;
	}
	pCBit=new CachedBitmap(pBit,&G);
	delete pBit;
	delete memG;
	InvalidateRect(hWndMain,NULL,FALSE);
}

void OnPaint(HDC hdc)
{
	Graphics G(hdc);

	if (pCBit == NULL) {
		UpdateScreen();
	}
	G.DrawCachedBitmap(pCBit,0,0);
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_KEYDOWN:
		switch (wParam) {
		case VK_LEFT:
			ex-=5;
			UpdateScreen();
			break;
		case VK_RIGHT:
			ex+=5;
			UpdateScreen();
			break;
		case VK_UP:
			ey-=5;
			UpdateScreen();
			break;
		case VK_DOWN:
			ey+=5;
			UpdateScreen();
			break;
		}
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		if (pCBit) {
			delete pCBit;
		}
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}
//*/
