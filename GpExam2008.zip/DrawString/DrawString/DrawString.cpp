#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("DrawString");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

TCHAR Mode=TEXT('1');
void OnPaint(HDC hdc)
{
	Graphics G(hdc);

	if (Mode == TEXT('1')) {
		// ���ڿ� ���
		Font F(L"Arial",20,FontStyleRegular,UnitPixel);
		PointF P(10.0f,10.0f);
		SolidBrush B(Color(0,0,255));
		
		G.DrawString(L"Test String",-1,&F,P,&B);
	} else if (Mode == TEXT('2')) {
		// �귯�÷� ȹ ���θ� ä��
		Font F(L"�ü�",100,FontStyleBold,UnitPixel);
		HatchBrush HB(HatchStyleWeave,Color(255,0,0),Color(255,255,0));
		LinearGradientBrush GB(Point(10,0),Point(600,0),Color(0,255,0),Color(0,0,255));
		
		G.DrawString(L"��ġ �귯��",-1,&F,PointF(10.0f,10.0f),&HB);
		G.DrawString(L"�׷����Ʈ",-1,&F,PointF(10.0f,110.0f),&GB);
	} else if (Mode == TEXT('3')) {
		// ���� ���
		Font F(L"Arial",20,FontStyleRegular,UnitPixel);
		PointF P(10.0f,10.0f);
		SolidBrush B(Color(0,0,255));
		StringFormat SF(StringFormatFlagsDirectionVertical);
		
		G.DrawString(L"Test String",-1,&F,P,&SF,&B);
	} else if (Mode == TEXT('4')) {
		// �簢 ���� �ȿ� ���ڿ� ���
		Font F(L"Arial",20,FontStyleRegular,UnitPixel);
		RectF R(10,10,200,200);
		SolidBrush B(Color(0,0,255));
		Pen P(Color(0,0,0));

		G.DrawRectangle(&P,R);
		G.DrawString(L"DrawString function draws a string in layout rectangle"
			L" with a specified font.",-1,&F,R,NULL,&B);
	} else if (Mode == TEXT('5')) {
		// �߾����� ����
		Font F(L"Arial",20,FontStyleRegular,UnitPixel);
		RectF R(10,10,200,200);
		SolidBrush B(Color(0,0,255));
		Pen P(Color(0,0,0));
		StringFormat SF;
		
		SF.SetAlignment(StringAlignmentCenter);
		SF.SetLineAlignment(StringAlignmentCenter);
		G.DrawRectangle(&P,R);
		G.DrawString(L"DrawString function draws a string in layout rectangle"
			L" with a specified font.",-1,&F,R,&SF,&B);
	} else if (Mode == TEXT('6')) {
		// �ü� 20�и������� ���� ����� �۲�
		Font F(L"�ü�",20,FontStyleBoldItalic,UnitMillimeter);
		PointF P(10.0f,10.0f);
		SolidBrush B(Color(255,0,0));
		
		G.DrawString(L"�ѱ� ���ڿ�",-1,&F,P,&B);
	} else if (Mode == TEXT('7')) {
		// ��Ʈ �йи��� ���� �����ϰ� ��Ʈ �����ϱ�
		FontFamily FM(L"�ü�");
		Font F(&FM,20,FontStyleBoldItalic,UnitMillimeter);
		PointF P(10.0f,10.0f);
		SolidBrush B(Color(255,0,0));
		
		G.DrawString(L"�ѱ� ���ڿ�",-1,&F,P,&B);
	} else if (Mode == TEXT('8')) {
		// ��Ʈ ����
		InstalledFontCollection IFC;
		FontFamily *arFM;
		Font *F;
		WCHAR name[LF_FACESIZE];
		int i,n,nf;
		SolidBrush S(Color(0,0,0));
		PointF P(0,0);

		n=IFC.GetFamilyCount();
		arFM=new FontFamily[n];
		IFC.GetFamilies(n,arFM,&nf);
		for (i=0;i<n;i++) {
			arFM[i].GetFamilyName(name);
			F=new Font(&arFM[i],25,FontStyleRegular,UnitPixel);
			G.DrawString(name,-1,F,P,&S);
			if (P.Y < 700) {
				P.Y+=25;
			} else {
				P.Y=0;
				P.X+=300;
			}
			delete F;
		}
		delete [] arFM;
	} else if (Mode == TEXT('9')) {
		// ��Ƽ �˸��ƽ� �׽�Ʈ
		Font F(L"�ü�",30,FontStyleRegular,UnitPixel);
		PointF P(10.0f,0.0f);
		SolidBrush B(Color(0,0,0));
		int i;
		
		for (i=0;i<=5;i++) {
			G.SetTextRenderingHint((TextRenderingHint)i);
			G.DrawString(L"Anti Aliasing Test ���ڸ� �ε巴�� ����Ѵ�.",-1,&F,P,&B);
			P.Y+=33;
		}
	}
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_KEYDOWN:
		Mode=(TCHAR)wParam;
		InvalidateRect(hWnd,NULL,TRUE);
		return 0;
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}