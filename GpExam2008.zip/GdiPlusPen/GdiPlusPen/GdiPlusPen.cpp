#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("GdiPlusPen");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

TCHAR Mode=TEXT('1');
void OnPaint(HDC hdc)
{
	Graphics G(hdc);

	if (Mode == TEXT('1')) {
		// ���� 3�� ������ ��
		Pen P(Color(255,0,0),3);

		G.DrawLine(&P,10,10,200,10);
	} else if (Mode == TEXT('2')) {
		// �귯�÷κ��� �� �����
		HatchBrush H(HatchStyleWeave,Color(255,0,0),Color(0,255,0));
		Pen P(&H,20);

		G.DrawEllipse(&P,20,20,300,200);
	} else if (Mode == TEXT('3')) {
		// �Ķ��� �׶��̼�
		int i;
		Pen P(Color(0,0,0));

		for (i=0;i<256;i++) {
			P.SetColor(Color(0,0,255-i));
			G.DrawLine(&P,0,i,300,i);
		}
	} else if (Mode == TEXT('4')) {
		// �� ��Ÿ��
		Pen P(Color(0,0,0),5);
		int i;

		for (i=0;i<5;i++) {
			P.SetDashStyle((DashStyle)i);
			G.DrawLine(&P,10,i*20+20,300,i*20+20);
		}
	} else if (Mode == TEXT('5')) {
		// ����� ���� ��Ÿ��
		Pen P(Color(0,0,0),5);
		REAL arDash[]={3.0f,1.0f,8.0f,2.0f,5.0f,1.0f};

		P.SetDashStyle(DashStyleCustom);
		P.SetDashPattern(arDash,sizeof(arDash)/sizeof(arDash[0]));
		G.DrawLine(&P,10,50,300,50);
	} else if (Mode == TEXT('6')) {
		// ���� �� ���
		Pen P(Color(0,0,0),10);

		P.SetStartCap(LineCapArrowAnchor);
		P.SetEndCap(LineCapDiamondAnchor);
		G.DrawLine(&P,30,30,300,30);
		P.SetStartCap(LineCapRound);
		P.SetEndCap(LineCapTriangle);
		G.DrawLine(&P,30,60,300,60);
		P.SetStartCap(LineCapSquareAnchor );
		P.SetEndCap(LineCapRoundAnchor );
		G.DrawLine(&P,30,90,300,90);
	} else if (Mode == TEXT('7')) {
		// �뽬 ���
		Pen P(Color(0,0,0),10);

		P.SetDashStyle(DashStyleDashDot);

		P.SetDashCap(DashCapFlat);
		G.DrawLine(&P,10,20,300,20);

		P.SetDashCap(DashCapRound);
		G.DrawLine(&P,10,40,300,40);

		P.SetDashCap(DashCapTriangle);
		G.DrawLine(&P,10,60,300,60);
	} else if (Mode == TEXT('8')) {
		// ���� ���
		Pen P(Color(0,0,0),15);

		P.SetLineJoin(LineJoinMiter);
		G.DrawRectangle(&P,10,10,60,60);

		P.SetLineJoin(LineJoinBevel);
		G.DrawRectangle(&P,110,10,60,60);

		P.SetLineJoin(LineJoinRound);
		G.DrawRectangle(&P,10,110,60,60);

		P.SetLineJoin(LineJoinMiterClipped);
		G.DrawRectangle(&P,110,110,60,60);
	} else if (Mode == TEXT('9')) {
		// ���� ���� ���
		Pen P(Color(192,192,192),15);
		Pen P2(Color(0,0,0),1);

		// �߽ɿ� ����
		P.SetAlignment(PenAlignmentCenter);
		G.DrawRectangle(&P,10,10,100,100);
		G.DrawLine(&P,10,150,300,150);

		// �������� ����
		P.SetAlignment(PenAlignmentInset);
		G.DrawRectangle(&P,200,10,100,100);
		G.DrawLine(&P,10,200,300,200);

		// Ȯ���� ���� �ȳ���
		G.DrawRectangle(&P2,10,10,100,100);
		G.DrawRectangle(&P2,200,10,100,100);
		G.DrawLine(&P2,10,150,300,150);
		G.DrawLine(&P2,10,200,300,200);
	}
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_KEYDOWN:
		Mode=(TCHAR)wParam;
		InvalidateRect(hWnd,NULL,TRUE);
		return 0;
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}