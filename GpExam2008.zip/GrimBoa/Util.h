#define FIF_DEEP 1
#define FIF_DIRFILTER 2
#define FIF_INCHID 4
typedef int (*FIFCALLBACK)(TCHAR *, DWORD, LPVOID);
BOOL BrowseFolder(HWND hParent, LPCTSTR szTitle, LPCTSTR StartPath, TCHAR *szFolder);
void FindInFiles(TCHAR *Path, TCHAR *Pattern, DWORD Flags, FIFCALLBACK pCallBack, LPVOID pCustom);
void SavePosition(HWND hWnd, TCHAR *Key);
void LoadPosition(HWND hWnd, TCHAR *Key, RECT *Def/*=NULL*/);
void MoveToParentCenter(HWND hWnd);
BOOL TestAssociate(LPCTSTR ext, LPCTSTR RegName);
void UnAssociate(LPCTSTR ext, LPCTSTR RegName);
void MakeAssociate(LPCTSTR ext, LPCTSTR RegName, LPCTSTR exe, LPCTSTR desc);
void ModifyAssociate(LPCTSTR ext, LPCTSTR RegName, LPCTSTR exe);
