#define _WIN32_WINNT 0x400
#define _WIN32_WINDOWS 0x401
#include <windows.h>
#include <gdiplus.h>
#include <io.h>
#include <commctrl.h>
#include <shlwapi.h>
#include <shlobj.h>
#include "resource.h"
#include "ShReg.h"
#include "Util.h"
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")

#define KEY "Software\\MiyoungSoft\\GrimBoa\\"

// ���� ����
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("GrimBoa");
HWND hAlbum;
TCHAR NowPath[MAX_PATH];
struct tag_File {
	TCHAR Name[MAX_PATH];
	int Size;
	int Order;
	FILETIME time;
	BOOL bMark;
};
tag_File *FileList;
int ListSize,ListNum;
BOOL bFitWindow;
BOOL bWrap;
BOOL bSlide;
UINT Interval;
BOOL bFull;
RECT rtNormal;
COLORREF BackColor=RGB(0,0,0);
struct tag_Slot {
	CachedBitmap *pCB;
	int idx;
	int width,height;
	int bpp;
};
tag_Slot Slot[3];	// 0��:���� �׸�, 1��:���� �׸�, 2��:���� �׸�
HANDLE hMutex;
HWND hState;
BOOL bDirectDelete;
BOOL bMarkDelete;
BOOL bRecycleDelete;
int SortOrder;
BOOL bSortAsc;
BOOL bReloadLast;

// �Լ� ����
LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK AlbumProc(HWND,UINT,WPARAM,LPARAM);
LRESULT OnCreate(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnDestroy(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnPaint(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnCommand(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnInitMenu(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnSize(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnDropFiles(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnTimer(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnMouseWheel(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnSetFocus(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT OnActivateApp(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT Album_OnPaint(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT Album_OnSize(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT Album_OnContextMenu(HWND hWnd,WPARAM wParam,LPARAM lParam);
LRESULT Album_OnKeyDown(HWND hWnd,WPARAM wParam,LPARAM lParam);

void MoveFolder(TCHAR *Path);
void MakeList();
void PrepareImage(int nSlot);
DWORD WINAPI PrepareThread(LPVOID temp);
void MovePicture(BOOL bNext);
void ChangeCaption();
void ResetCache();
void SetSlot(int idx);
void DeleteImage();
int GetNextIdx(int idx);
BOOL CALLBACK OptionDlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
void DeleteMarked();
BOOL DeleteImageFile(TCHAR *Path);

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;
	ULONG_PTR gpToken;
	GdiplusStartupInput gpsi;
	if (GdiplusStartup(&gpToken,&gpsi,NULL) != Ok) {
		MessageBox(NULL,"GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�.","�˸�",MB_OK);
		return 0;
	}
	
	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(hInstance,MAKEINTRESOURCE(IDI_ICON1));
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=MAKEINTRESOURCE(IDR_MENU1);
	WndClass.style=0;
	RegisterClass(&WndClass);
	
	WndClass.lpfnWndProc=AlbumProc;
	WndClass.hbrBackground=NULL;
	WndClass.lpszClassName="Album";
	WndClass.lpszMenuName=NULL;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,"�׸�����",WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);
	
	HACCEL hAccel;

	hAccel=LoadAccelerators(hInstance,MAKEINTRESOURCE(IDR_ACCELERATOR1));
	while(GetMessage(&Message,0,0,0)) {
		if (!TranslateAccelerator(hWnd,hAccel,&Message)) {
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}
	}
	GdiplusShutdown(gpToken);
	return (int)Message.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	switch(iMessage) {
	case WM_CREATE:
		return OnCreate(hWnd,wParam,lParam);
	case WM_DESTROY:
		return OnDestroy(hWnd,wParam,lParam);
	case WM_PAINT:
		return OnPaint(hWnd,wParam,lParam);
	case WM_COMMAND:
		return OnCommand(hWnd,wParam,lParam);
	case WM_INITMENU:
		return OnInitMenu(hWnd,wParam,lParam);
	case WM_SIZE:
		return OnSize(hWnd,wParam,lParam);
	case WM_DROPFILES:
		return OnDropFiles(hWnd,wParam,lParam);
	case WM_TIMER:
		return OnTimer(hWnd,wParam,lParam);
	case WM_MOUSEWHEEL:
		return OnMouseWheel(hWnd,wParam,lParam);
	case WM_SETFOCUS:
		return OnSetFocus(hWnd,wParam,lParam);
	case WM_ACTIVATEAPP:
		return OnActivateApp(hWnd,wParam,lParam);
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}

LRESULT OnCreate(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	int i;
	DWORD dwThread;
	int SBPart[]={100,220,300,-1};
	TCHAR InstallPath[MAX_PATH];
	TCHAR Path[MAX_PATH];

	hWndMain=hWnd;
	hAlbum=CreateWindow("Album","",WS_CHILD | WS_VISIBLE,
		0,0,0,0,hWnd,(HMENU)0,g_hInst,NULL);
	bFitWindow=TRUE;
	bWrap=FALSE;
	bSlide=FALSE;
	Interval=3000;
	bFull=FALSE;
	DragAcceptFiles(hWnd,TRUE);
	hMutex=CreateMutex(NULL,FALSE,NULL);
	for (i=0;i<3;i++) {
		Slot[i].pCB=NULL;
		Slot[i].idx=-1;
	}
	CloseHandle(CreateThread(NULL,0,PrepareThread,NULL,0,&dwThread));

	InitCommonControls();
	hState=CreateStatusWindow(WS_CHILD | WS_VISIBLE, "", hWnd,0);
	SendMessage(hState, SB_SETPARTS,sizeof(SBPart)/sizeof(SBPart[0]), (LPARAM)SBPart);

	SHRegReadString(SHCU,KEY"Setting","NowPath","",NowPath,MAX_PATH);
	bDirectDelete=SHRegReadInt(SHCU,KEY"Setting","bDirectDelete",0);
	Interval=SHRegReadInt(SHCU,KEY"Setting","Interval",3000);
	bFitWindow=SHRegReadInt(SHCU,KEY"Setting","bFitWindow",1);
	bWrap=SHRegReadInt(SHCU,KEY"Setting","bWrap",0);
	BackColor=SHRegReadInt(SHCU,KEY"Setting","BackColor",0);
	bMarkDelete=SHRegReadInt(SHCU,KEY"Setting","bMarkDelete",0);
	bRecycleDelete=SHRegReadInt(SHCU,KEY"Setting","bRecycleDelete",1);
	SortOrder=SHRegReadInt(SHCU,KEY"Setting","SortOrder",1);
	bSortAsc=SHRegReadInt(SHCU,KEY"Setting","bSortAsc",1);
	bReloadLast=SHRegReadInt(SHCU,KEY"Setting","bReloadLast",0);

	SHRegReadString(SHCU,KEY"Setting","InstallPath","First",InstallPath,MAX_PATH);
	GetModuleFileName(g_hInst,Path,MAX_PATH);

	// ù ������ ���� ��ġ ��θ� ����� ���´�.
	if (lstrcmp(InstallPath,"First")==0) {
		SHRegWriteString(SHCU,KEY"Setting","InstallPath",Path);
	// ��ġ�� ��ΰ� ����Ǿ����� ����� ��θ� �����Ѵ�.
	} else if (lstrcmpi(Path,InstallPath) != 0) {
		SHRegWriteString(SHCU,KEY"Setting","InstallPath",Path);
		ModifyAssociate(".png","GrimBoa",Path);
		ModifyAssociate(".gif","GrimBoa",Path);
		ModifyAssociate(".jpg","GrimBoa",Path);
		ModifyAssociate(".jpeg","GrimBoa",Path);
		ModifyAssociate(".bmp","GrimBoa",Path);
		ModifyAssociate(".tif","GrimBoa",Path);
	}

	// �μ��� ���޵� ������ ������ �о�´�.
	if (__argc > 1) {
		MoveFolder(__argv[1]);
	} else {
		if (bReloadLast) {
			MoveFolder(NowPath);
		}
	}
	return 0;
}

LRESULT OnDestroy(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	int i;

	if (FileList) {
		free(FileList);
	}
	WaitForSingleObject(hMutex,INFINITE);
	for (i=0;i<3;i++) {
		delete Slot[i].pCB;
	}
	ReleaseMutex(hMutex);
	CloseHandle(hMutex);
	SavePosition(hWnd,KEY"Position");
	SHRegWriteString(SHCU,KEY"Setting","NowPath",NowPath);
	SHRegWriteInt(SHCU,KEY"Setting","bDirectDelete",bDirectDelete);
	SHRegWriteInt(SHCU,KEY"Setting","Interval",Interval);
	SHRegWriteInt(SHCU,KEY"Setting","bFitWindow",bFitWindow);
	SHRegWriteInt(SHCU,KEY"Setting","bWrap",bWrap);
	SHRegWriteInt(SHCU,KEY"Setting","BackColor",BackColor);
	SHRegWriteInt(SHCU,KEY"Setting","bMarkDelete",bMarkDelete);
	SHRegWriteInt(SHCU,KEY"Setting","bRecycleDelete",bRecycleDelete);
	SHRegWriteInt(SHCU,KEY"Setting","SortOrder",SortOrder);
	SHRegWriteInt(SHCU,KEY"Setting","bSortAsc",bSortAsc);
	SHRegWriteInt(SHCU,KEY"Setting","bReloadLast",bReloadLast);
	PostQuitMessage(0);
	return 0;
}

LRESULT OnPaint(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	PAINTSTRUCT ps;

	BeginPaint(hWnd,&ps);
	EndPaint(hWnd,&ps);
	return 0;
}

LRESULT OnCommand(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	switch (LOWORD(wParam)) {
	case IDM_FILE_DIR:
		if (BrowseFolder(hWnd,"�׸� ������ �ִ� ���� ����",NowPath,NowPath)) {
			MoveFolder(NowPath);
		}
		break;
	case IDM_FILE_DELETE:
		DeleteImage();
		break;
	case IDM_FILE_DELMARK:
		DeleteMarked();
		break;
	case IDM_FILE_OPTION:
		DialogBox(g_hInst,MAKEINTRESOURCE(IDD_DLGOPTION),hWnd,OptionDlgProc);
		break;
	case IDM_VIEW_FITWINDOW:
		bFitWindow=!bFitWindow;
		ResetCache();
		break;
	case IDM_VIEW_FULL:
		bFull=!bFull;
		if (bFull) {
			GetWindowRect(hWnd,&rtNormal);
			SetWindowLong(hWnd,GWL_STYLE,WS_POPUP | WS_VISIBLE);
			SetWindowPos(hWnd,HWND_NOTOPMOST,0,0,GetSystemMetrics(SM_CXSCREEN),
				GetSystemMetrics(SM_CYSCREEN),SWP_FRAMECHANGED);
			SetMenu(hWnd,NULL);
			ShowWindow(hState,SW_HIDE);
		} else {
			SetWindowLong(hWnd,GWL_STYLE,WS_OVERLAPPEDWINDOW | WS_VISIBLE);
			SetWindowPos(hWnd,HWND_NOTOPMOST,rtNormal.left,rtNormal.top,
				rtNormal.right-rtNormal.left,rtNormal.bottom-rtNormal.top,0);
			SetMenu(hWnd,LoadMenu(g_hInst,MAKEINTRESOURCE(IDR_MENU1)));
			ShowWindow(hState,SW_SHOW);
		}
		break;
	case IDM_VIEW_SLIDESHOW:
		if (bSlide==FALSE) {
			SetTimer(hWnd,0,Interval,NULL);
		} else {
			KillTimer(hWnd,0);
		}
		bSlide=!bSlide;
		break;
	case IDM_VIEW_WRAP:
		bWrap=!bWrap;
		break;
	case IDM_MOVE_NEXT:
		MovePicture(TRUE);
		break;
	case IDM_MOVE_PREV:
		MovePicture(FALSE);
		break;
	case IDM_MOVE_HOME:
		SetSlot(0);
		break;
	case IDM_MOVE_END:
		SetSlot(ListNum-1);
		break;
	}
	return 0;
}

LRESULT OnInitMenu(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	CheckMenuItem((HMENU)wParam,IDM_VIEW_FITWINDOW,
		MF_BYCOMMAND | (bFitWindow ? MF_CHECKED:MF_UNCHECKED));
	CheckMenuItem((HMENU)wParam,IDM_VIEW_FULL,
		MF_BYCOMMAND | (bFull ? MF_CHECKED:MF_UNCHECKED));
	CheckMenuItem((HMENU)wParam,IDM_VIEW_WRAP,
		MF_BYCOMMAND | (bWrap ? MF_CHECKED:MF_UNCHECKED));
	CheckMenuItem((HMENU)wParam,IDM_VIEW_SLIDESHOW,
		MF_BYCOMMAND | (bSlide ? MF_CHECKED:MF_UNCHECKED));
	return 0;
}

LRESULT OnSize(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	RECT crt,srt;

	if (wParam != SIZE_MINIMIZED) {
		SendMessage(hState, WM_SIZE, wParam, lParam);
		GetClientRect(hState,&srt);
		GetClientRect(hWnd,&crt);
		if (bFull) {
			MoveWindow(hAlbum,0,0,crt.right,crt.bottom,TRUE);
		} else {
			MoveWindow(hAlbum,0,0,crt.right,crt.bottom-(srt.bottom),TRUE);
		}
	}
	return 0;
}

LRESULT OnDropFiles(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	TCHAR DropPath[MAX_PATH];

	DragQueryFile((HDROP)wParam,0,DropPath,MAX_PATH);
	MoveFolder(DropPath);
	return 0;
}

LRESULT OnTimer(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	MovePicture(TRUE);
	return 0;
}

LRESULT OnMouseWheel(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	if ((short)HIWORD(wParam) == WHEEL_DELTA) {
		MovePicture(FALSE);
	} else {
		MovePicture(TRUE);
	}
	return 0;
}

LRESULT OnSetFocus(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	SetFocus(hAlbum);
	return 0;
}

LRESULT OnActivateApp(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	static BOOL bFirst=TRUE;

	if (bFirst==TRUE) {
		bFirst=FALSE;
		LoadPosition(hWnd,KEY"Position",NULL);
	}

	// ��ü ȭ�� ���¿��� ��Ȱ��ȭ�� �� ž ��Ʈ �Ӽ��� ������ �Ѵ�.
	if (bFull) {
		if (wParam == TRUE) {
			SetWindowPos(hWnd,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE | SWP_NOSIZE);
		} else {
			SetWindowPos(hWnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE | SWP_NOSIZE);
		}
	}
	return 0;
}

LRESULT CALLBACK AlbumProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	switch(iMessage) {
	case WM_PAINT:
		return Album_OnPaint(hWnd,wParam,lParam);
	case WM_SIZE:
		return Album_OnSize(hWnd,wParam,lParam);
	case WM_CONTEXTMENU:
		return Album_OnContextMenu(hWnd,wParam,lParam);
	case WM_KEYDOWN:
		return Album_OnKeyDown(hWnd,wParam,lParam);
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}

LRESULT Album_OnPaint(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	hdc=BeginPaint(hWnd, &ps);
	// ���� �׸��� �ϼ��Ǿ� ���� ���� �׸���.
	if (Slot[1].pCB != NULL) {
		Graphics G(hdc);
		G.DrawCachedBitmap(Slot[1].pCB,0,0);
		// ���� ����� �׸��� X�� ǥ��
		if (FileList[Slot[1].idx].bMark == TRUE) {
			Pen P(Color(128,255,0,0),20);
			RECT crt;
			GetClientRect(hWnd,&crt);
			G.DrawLine(&P,crt.right/4,crt.bottom/4,crt.right*3/4,crt.bottom*3/4);
			G.DrawLine(&P,crt.right*3/4,crt.bottom/4,crt.right/4,crt.bottom*3/4);
		}
	}
	EndPaint(hWnd, &ps);
	return 0;
}

LRESULT Album_OnSize(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	if (wParam != SIZE_MINIMIZED) {
		ResetCache();
	}
	return 0;
}

LRESULT Album_OnContextMenu(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	HMENU hMenu, hPopup;

	hMenu=LoadMenu(g_hInst, MAKEINTRESOURCE(IDR_POPUP));
	hPopup=GetSubMenu(hMenu, 0);

	TrackPopupMenu(hPopup, TPM_LEFTALIGN, LOWORD(lParam), HIWORD(lParam), 
		0, hWndMain, NULL);
	DestroyMenu(hMenu);
	return 0;
}

LRESULT Album_OnKeyDown(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	if (wParam == VK_ESCAPE && bFull) {
		SendMessage(hWndMain,WM_COMMAND,MAKEWPARAM(IDM_VIEW_FULL,0),0);
	}
	return 0;
}

//////////////////////////////////////////////////////////////////////////////
// �Ϲ� �Լ���

void MoveFolder(TCHAR *Path)
{
	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];
	TCHAR FileName[MAX_PATH];
	int i,idx;

	if (GetFileAttributes(Path) & FILE_ATTRIBUTE_DIRECTORY) {
		lstrcpy(NowPath,Path);
		lstrcpy(FileName,"");
	} else {
		_splitpath(Path,drive,dir,fname,ext);
		wsprintf(NowPath,"%s%s",drive,dir);
		NowPath[lstrlen(NowPath)-1]=0;
		wsprintf(FileName,"%s%s",fname,ext);
	}
	MakeList();
	if (lstrlen(FileName) == 0) {
		idx=0;
	} else {
		// ������ �巡�������� ��� ������ ã�� �����ش�.
		for (i=0;i<ListNum;i++) {
			if (lstrcmp(FileList[i].Name,FileName) == 0) {
				break;
			}
		}
		// �̹��� ������ �巡�� ���� ���� ��� ��Ͽ� ���� ���� �ִ�.
		if (i == ListNum) {
			idx=0;
		} else {
			idx=i;
		}
	}
	SetSlot(idx);
}

int OnFindImage(TCHAR *Path,DWORD Attr,LPVOID Param)
{
	TCHAR Ext[_MAX_EXT];
	TCHAR Name[MAX_PATH];
	HANDLE hFile;

	_splitpath(Path,NULL,NULL,Name,Ext);
	if ((Attr & FILE_ATTRIBUTE_DIRECTORY)==0) {
		if (ListNum == ListSize) {
			ListSize+=1000;
			FileList=(tag_File *)realloc(FileList,sizeof(tag_File)*ListSize);
		}
		wsprintf(FileList[ListNum].Name,"%s%s",Name,Ext);
		hFile=CreateFile(Path,0,0,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		FileList[ListNum].Size=GetFileSize(hFile,NULL);
		GetFileTime(hFile,&FileList[ListNum].time,NULL,NULL);
		CloseHandle(hFile);
		FileList[ListNum].bMark=FALSE;
		ListNum++;
	}
	return 0;
}

int compare(const void *a, const void *b)
{
	tag_File *f1,*f2;
	f1=(tag_File *)a;
	f2=(tag_File *)b;
	int Result;

	switch (SortOrder) {
	case 2:
		Result=lstrcmp(f1->Name,f2->Name);
		break;
	case 3:
		Result=f1->Size-f2->Size;
		break;
	case 4:
		Result=CompareFileTime(&f1->time,&f2->time);
		break;
	}

	if (bSortAsc==FALSE) Result*=-1;
	return Result;
}

void MakeList()
{
	if (FileList == NULL) {
		ListSize=1000;
		FileList=(tag_File *)malloc(sizeof(tag_File)*ListSize);
	}
	WaitForSingleObject(hMutex,INFINITE);
	ListNum=0;
	FindInFiles(NowPath,"*.jpg;*.bmp;*.gif;*.png;*.tif;*.jpeg",
		FIF_INCHID, OnFindImage,NULL);
	// ���� �ɼ��� �����Ǿ� ������ ����� �����Ѵ�.
	if (SortOrder != 1) {
		qsort(FileList,ListNum,sizeof(tag_File),compare);
	}
	ReleaseMutex(hMutex);
}

// ��׶��忡�� �� ������ ĳ�� �̹����� ��� �����. 
// �� ������� ���Ը� �����ϸ� �ȴ�.
DWORD WINAPI PrepareThread(LPVOID temp)
{
	int i;
	int ar[]={1,2,0};		// �������̸� 1���� ���� �׸����� �Ѵ�.

	for (;;) {
		if (ListNum == 0) {
			Sleep(50);
		} else {
			for (i=0;i<3;i++) {
				WaitForSingleObject(hMutex,INFINITE);
				if (Slot[ar[i]].idx != -1 && Slot[ar[i]].pCB == NULL) {
					PrepareImage(ar[i]);
					Sleep(0);
				}
				ReleaseMutex(hMutex);
			}
			// ���� ������ ������ CPU �������� �ʹ� �������Ƿ� ƴƴ�� ����.
			Sleep(21);
		}
	}
}

void PrepareImage(int nSlot)
{
	TCHAR ImagePath[MAX_PATH];
	WCHAR ImagePath2[MAX_PATH];
	RECT art;
	int iw,ih;
	int l,t,r,b,tsize;
	Color BgColor;
	Bitmap *pBit;

	Graphics G(hWndMain);
	GetClientRect(hAlbum,&art);
	Bitmap Back(art.right,art.bottom,&G);
	Graphics BackG(&Back);
	BgColor.SetFromCOLORREF(BackColor);
	BackG.FillRectangle(&SolidBrush(BgColor),0,0,art.right,art.bottom);
	
	if (FileList == NULL) {
		goto end;
	}

	wsprintf(ImagePath,"%s\\%s",NowPath,FileList[Slot[nSlot].idx].Name);
	if (_access(ImagePath,0)!=0) {
		goto end;
	}

	MultiByteToWideChar(CP_ACP, 0, ImagePath, -1, ImagePath2, MAX_PATH);
	pBit=new Bitmap(ImagePath2);
	iw=pBit->GetWidth();
	ih=pBit->GetHeight();
	Slot[nSlot].width=iw;
	Slot[nSlot].height=ih;
	
	switch (pBit->GetPixelFormat()) {
	case PixelFormat1bppIndexed:
		Slot[nSlot].bpp=1;
		break;
	case PixelFormat4bppIndexed:
		Slot[nSlot].bpp=4;
		break;
	case PixelFormat8bppIndexed:
		Slot[nSlot].bpp=8;
		break;
	case PixelFormat16bppARGB1555:
	case PixelFormat16bppGrayScale:
	case PixelFormat16bppRGB555:
	case PixelFormat16bppRGB565:
		Slot[nSlot].bpp=16;
		break;
	case PixelFormat24bppRGB:
		Slot[nSlot].bpp=24;
		break;
	case PixelFormat32bppARGB:
	case PixelFormat32bppPARGB:
	case PixelFormat32bppRGB:
		Slot[nSlot].bpp=32;
		break;
	default:
		Slot[nSlot].bpp=32;
		break;
	}

	// �۾� �����ȿ� �� ���� �� �ִ� ���
	if (iw < art.right && ih < art.bottom) {
		l=art.right/2-iw/2;
		t=art.bottom/2-ih/2;
		r=l+iw;
		b=t+ih;
	} else {
		if (bFitWindow) {
			// �̹����� ��Ⱦ�� �� ũ�� : ȭ���� ���η� ������ ��
			if ((double)iw/ih > (double)art.right/art.bottom) {
				l=0;
				r=art.right;
				// ȭ�� ���� ������ŭ �׸��� ���� ���δ�.
				tsize=int(ih*art.right/(double)iw);
				t=art.bottom/2-tsize/2;
				b=t+tsize;
			} else {
				t=0;
				b=art.bottom;
				tsize=int(iw*art.bottom/(double)ih);
				l=art.right/2-tsize/2;
				r=l+tsize;
			}
		} else {
			l=(art.right-iw)/2;
			t=(art.bottom-ih)/2;
			r=l+iw;
			b=l+ih;
		}
	}
	BackG.SetInterpolationMode(InterpolationModeHighQuality);
	BackG.DrawImage(pBit,l,t,r-l,b-t);
	delete pBit;
end:
	Slot[nSlot].pCB=new CachedBitmap(&Back,&G);
}

// idx��° �׸� ���� ��ȣ ����
int GetNextIdx(int idx)
{
	if (idx == ListNum -1) {
		if (bWrap) {
			return 0;
		} else {
			return -1;
		}
	} else {
		return idx+1;
	}
}

void MovePicture(BOOL bNext)
{
	if (bNext) {
		if (Slot[2].idx != -1) {
			// ���� �׸��� �غ�� ������ ���
			while (Slot[2].pCB == NULL) Sleep(21);
			WaitForSingleObject(hMutex,INFINITE);
			// ������ ��ĭ�� ���� �ø���.
			delete Slot[0].pCB;
			Slot[0]=Slot[1];
			Slot[1]=Slot[2];
			Slot[2].pCB=NULL;
			// ���� �׸��� �ε��� ����
			Slot[2].idx=GetNextIdx(Slot[1].idx);
			ReleaseMutex(hMutex);
		}
	} else {
		if (Slot[0].idx != -1) {
			while (Slot[0].pCB == NULL) Sleep(21);
			WaitForSingleObject(hMutex,INFINITE);
			delete Slot[2].pCB;
			Slot[2]=Slot[1];
			Slot[1]=Slot[0];
			Slot[0].pCB=NULL;
			if (Slot[1].idx == 0) {
				if (bWrap) {
					Slot[0].idx=ListNum-1;
				} else {
					Slot[0].idx=-1;
				}
			} else {
				Slot[0].idx=Slot[1].idx-1;
			}
			ReleaseMutex(hMutex);
		}
	}
	InvalidateRect(hAlbum,NULL,FALSE);
	ChangeCaption();
}

void ChangeCaption()
{
	TCHAR Cap[MAX_PATH];
	int idx;

	idx=Slot[1].idx;

	if (idx == -1) {
		lstrcpy(Cap,"�׸�����");
	} else {
		wsprintf(Cap,"�׸����� - %s",FileList[idx].Name);
	}
	SetWindowText(hWndMain,Cap);

	if (idx != -1) {
		wsprintf(Cap,"%d/%d",idx+1,ListNum);
		SendMessage(hState, SB_SETTEXT, 0, (LPARAM)Cap);

		wsprintf(Cap,"%d*%d,%dBit",Slot[1].width,Slot[1].height,Slot[1].bpp);
		SendMessage(hState, SB_SETTEXT, 1, (LPARAM)Cap);

		if (FileList[idx].bMark) {
			lstrcpy(Cap,"�������");
		} else {
			lstrcpy(Cap,"");
		}
		SendMessage(hState, SB_SETTEXT, 2, (LPARAM)Cap);

		wsprintf(Cap,"%s\\%s",NowPath,FileList[idx].Name);
		SendMessage(hState, SB_SETTEXT, 3, (LPARAM)Cap);
	}
}

// ĳ�� �̹����� �ٽ� ������ �� �� ĳ�� �̹����� �����.
void ResetCache()
{
	int i;

	WaitForSingleObject(hMutex,INFINITE);
	for (i=0;i<3;i++) {
		delete Slot[i].pCB;
		Slot[i].pCB=NULL;
	}
	ReleaseMutex(hMutex);
	if (ListNum != 0) {
		while (Slot[1].pCB == NULL) Sleep(21);
		InvalidateRect(hAlbum,NULL,TRUE);
	}
}

// idx��° �׸��� �����ֵ��� ������ �����Ѵ�.
void SetSlot(int idx)
{
	int i;

	WaitForSingleObject(hMutex,INFINITE);
	for (i=0;i<3;i++) {
		delete Slot[i].pCB;
		Slot[i].pCB=NULL;
		Slot[i].idx=-1;
	}
	if (idx < ListNum) {
		Slot[1].idx=idx;
	}
	if (idx-1 > 0) {
		Slot[0].idx=idx-1;
	} else {
		if (bWrap) Slot[0].idx=ListNum-1;
	}
	if (idx+1 < ListNum) {
		Slot[2].idx=idx+1;
	} else {
		if (bWrap && ListNum) Slot[2].idx=0;
	}
	ReleaseMutex(hMutex);

	// ������ �׸��� �� ���� ������ ����Ѵ�.
	if (ListNum != 0) {
		while (Slot[1].pCB == NULL) Sleep(0);
		ChangeCaption();
		InvalidateRect(hAlbum,NULL,TRUE);
	}
}

BOOL CALLBACK OptionDlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	static BOOL bPng,bGif,bJpg,bBmp,bTif;
	UINT Check;
	static COLORREF crTemp[16];
	CHOOSECOLOR COL;
	int temp;
	TCHAR exe[MAX_PATH];

	switch(iMessage) {
	case WM_INITDIALOG:
		MoveToParentCenter(hDlg);
		CheckDlgButton(hDlg,IDC_CHKDIRECTDELETE,bDirectDelete ? BST_CHECKED:BST_UNCHECKED);
		CheckDlgButton(hDlg,IDC_CHKMARK,bMarkDelete ? BST_CHECKED:BST_UNCHECKED);
		CheckDlgButton(hDlg,IDC_CHKRECYCLE,bRecycleDelete ? BST_CHECKED:BST_UNCHECKED);
		CheckRadioButton(hDlg,IDC_SORT1,IDC_SORT4,IDC_SORT1+SortOrder-1);
		CheckDlgButton(hDlg,IDC_SORTASC,bSortAsc ? BST_CHECKED:BST_UNCHECKED);
		CheckDlgButton(hDlg,IDC_CHKRELOAD,bReloadLast ? BST_CHECKED:BST_UNCHECKED);
		SetDlgItemInt(hDlg,IDC_EDINTERVAL,Interval,FALSE);

		// Ȯ���� ���� ���¸� ���� �ش�.
		if (bPng=TestAssociate(".png","GrimBoa")) {
			CheckDlgButton(hDlg,IDC_CHKPNG,BST_CHECKED);
		}
		if (bGif=TestAssociate(".gif","GrimBoa")) {
			CheckDlgButton(hDlg,IDC_CHKGIF,BST_CHECKED);
		}
		if (bJpg=TestAssociate(".jpg","GrimBoa")) {
			CheckDlgButton(hDlg,IDC_CHKJPG,BST_CHECKED);
		}
		if (bBmp=TestAssociate(".bmp","GrimBoa")) {
			CheckDlgButton(hDlg,IDC_CHKBMP,BST_CHECKED);
		}
		if (bTif=TestAssociate(".tif","GrimBoa")) {
			CheckDlgButton(hDlg,IDC_CHKTIF,BST_CHECKED);
		}
		return TRUE;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDC_BTNBACKCOLOR:
			memset(&COL, 0, sizeof(CHOOSECOLOR));
			COL.lStructSize = sizeof(CHOOSECOLOR);
			COL.hwndOwner=hDlg;
			COL.lpCustColors=crTemp;
			if (ChooseColor(&COL)!=0) {
				BackColor=COL.rgbResult;
				MoveFolder(NowPath);
			}
			return TRUE;
		case IDC_BTNSELALL:
		case IDC_BTNCLEARALL:
			if (LOWORD(wParam) == IDC_BTNSELALL) {
				Check=BST_CHECKED;
			} else {
				Check=BST_UNCHECKED;
			}
			CheckDlgButton(hDlg,IDC_CHKPNG,Check);
			CheckDlgButton(hDlg,IDC_CHKGIF,Check);
			CheckDlgButton(hDlg,IDC_CHKJPG,Check);
			CheckDlgButton(hDlg,IDC_CHKBMP,Check);
			CheckDlgButton(hDlg,IDC_CHKTIF,Check);
			return TRUE;
		case IDOK:
			temp=GetDlgItemInt(hDlg,IDC_EDINTERVAL,NULL,FALSE);
			if (temp < 1000 || temp > 60000) {
				MessageBox(hDlg,"�����̴� �ֱ�� 1000 ~ 60000 ���̿��� �մϴ�.","�˸�",MB_OK);
				return TRUE;
			}
			Interval=temp;
			bDirectDelete=IsDlgButtonChecked(hDlg,IDC_CHKDIRECTDELETE);
			bMarkDelete=IsDlgButtonChecked(hDlg,IDC_CHKMARK);
			bRecycleDelete=IsDlgButtonChecked(hDlg,IDC_CHKRECYCLE);
			if (IsDlgButtonChecked(hDlg,IDC_SORT1)==BST_CHECKED) SortOrder=1;
			if (IsDlgButtonChecked(hDlg,IDC_SORT2)==BST_CHECKED) SortOrder=2;
			if (IsDlgButtonChecked(hDlg,IDC_SORT3)==BST_CHECKED) SortOrder=3;
			if (IsDlgButtonChecked(hDlg,IDC_SORT4)==BST_CHECKED) SortOrder=4;
			bSortAsc=IsDlgButtonChecked(hDlg,IDC_SORTASC);
			bReloadLast=IsDlgButtonChecked(hDlg,IDC_CHKRELOAD);

			GetModuleFileName(g_hInst,exe,MAX_PATH);
			if (bPng != (IsDlgButtonChecked(hDlg,IDC_CHKPNG)==BST_CHECKED)) {
				if (bPng==FALSE) {
					MakeAssociate(".png","GrimBoa",exe,"�׸����� ����");
				} else {
					UnAssociate(".png","GrimBoa");
				}
			}
			if (bGif != (IsDlgButtonChecked(hDlg,IDC_CHKGIF)==BST_CHECKED)) {
				if (bGif==FALSE) {
					MakeAssociate(".gif","GrimBoa",exe,"�׸����� ����");
				} else {
					UnAssociate(".gif","GrimBoa");
				}
			}
			if (bJpg != (IsDlgButtonChecked(hDlg,IDC_CHKJPG)==BST_CHECKED)) {
				if (bJpg==FALSE) {
					MakeAssociate(".jpg","GrimBoa",exe,"�׸����� ����");
					MakeAssociate(".jpeg","GrimBoa",exe,"�׸����� ����");
				} else {
					UnAssociate(".jpg","GrimBoa");
					UnAssociate(".jpeg","GrimBoa");
				}
			}
			if (bBmp != (IsDlgButtonChecked(hDlg,IDC_CHKBMP)==BST_CHECKED)) {
				if (bBmp==FALSE) {
					MakeAssociate(".bmp","GrimBoa",exe,"�׸����� ����");
				} else {
					UnAssociate(".bmp","GrimBoa");
				}
			}
			if (bTif != (IsDlgButtonChecked(hDlg,IDC_CHKTIF)==BST_CHECKED)) {
				if (bTif==FALSE) {
					MakeAssociate(".tif","GrimBoa",exe,"�׸����� ����");
				} else {
					UnAssociate(".tif","GrimBoa");
				}
			}
			EndDialog(hDlg,IDOK);
			return TRUE;
		case IDCANCEL:
			EndDialog(hDlg,IDCANCEL);
			return TRUE;
		}
		break;
	}
	return FALSE;
}

/*
// ext Ȯ���ڿ� ���� GrimBoa.ext Ű�� �����.
void MakeAssociateKey(TCHAR *ext, TCHAR *desc)
{
	TCHAR ProgID[MAX_PATH];
	TCHAR szKey[MAX_PATH];
	TCHAR Path[MAX_PATH];
	TCHAR Value[MAX_PATH];

	// Ű ����. ������ ������ �� �ʿ����.
	wsprintf(ProgID,"GrimBoa.%s",ext);
	if (desc) {
		SHRegWriteString(SHCR,ProgID,NULL,desc);
	}

	// ������ ����
	wsprintf(szKey,"%s\\DefaultIcon",ProgID);
	GetModuleFileName(g_hInst,Path,MAX_PATH);
	wsprintf(Value,"\"%s\",0",Path);
	SHRegWriteString(SHCR,szKey,NULL,Value);

	// open Ŀ�ǵ� ����
	wsprintf(szKey,"%s\\shell\\open\\command",ProgID);
	GetModuleFileName(g_hInst,Path,MAX_PATH);
	wsprintf(Value,"\"%s\" \"%%1\"",Path);
	SHRegWriteString(SHCR,szKey,NULL,Value);
}

// ext Ȯ���ڰ� ����Ǿ� �ִ��� �����Ѵ�.
BOOL TestAssociateExt(TCHAR *ext)
{
	TCHAR OldProgID[MAX_PATH];
	TCHAR NewProgID[MAX_PATH];
	TCHAR Key[32];

	// ���� ���� ���α׷��� ID�� ���Ѵ�.
	wsprintf(Key,".%s",ext);
	SHRegReadString(SHCR,Key,NULL,"",OldProgID,MAX_PATH);

	// �׸������� ���� ID�� ��ġ�ϸ� ����Ǿ� �ִ� ���̴�.
	wsprintf(NewProgID,"GrimBoa.%s",ext);
	if (lstrcmpi(OldProgID,NewProgID)==0) {
		return TRUE;
	} else {
		return FALSE;
	}
}

// ext Ȯ���ڸ� �׸����ƿ� ���� �Ǵ� �����Ѵ�.
void AssociateExt(TCHAR *ext,BOOL bAsso)
{
	TCHAR OldProgID[MAX_PATH];
	TCHAR NewProgID[MAX_PATH];
	TCHAR Key[32],ExplorerKey[MAX_PATH];

	wsprintf(Key,".%s",ext);
	wsprintf(ExplorerKey,"Software\\Microsoft\\Windows\\CurrentVersion\\"
		"Explorer\\FileExts\\.%s",ext);
	if (bAsso) {
		// ���� ���� ���α׷��� ID�� ���Ѵ�.
		SHRegReadString(SHCR,Key,NULL,"",OldProgID,MAX_PATH);

		// �׸����ƿ� �����Ѵ�.
		wsprintf(NewProgID,"GrimBoa.%s",ext);
		SHRegWriteString(SHCR,Key,NULL,NewProgID);
		SHRegWriteString(SHCU,ExplorerKey,"Progid",NewProgID);

		// ���� ���� ���α׷��� ID�� ������ ���´�. ��, �׸����ư� �ߺ� ������ ���� �������� �ʴ´�.
		if (lstrcmpi(OldProgID,NewProgID)!=0) {
			SHRegWriteString(SHCR,Key,"GrimBoaOldProgID",OldProgID);
		}
	} else {
		// ���� ���� ���α׷��� ���Ѵ�.
		SHRegReadString(SHCR,Key,"GrimBoaOldProgID","",OldProgID,MAX_PATH);

		// ���� ���� ���α׷����� �翬���Ѵ�.
		SHRegWriteString(SHCR,Key,NULL,OldProgID);
		SHRegWriteString(SHCU,ExplorerKey,"Progid",OldProgID);
	}
	SHChangeNotify(SHCNE_ASSOCCHANGED,SHCNF_IDLIST,NULL,NULL);
}
*/
// ������ �����Ѵ�.
void DeleteImage()
{
	BOOL bDelete;
	TCHAR Path[MAX_PATH]={0,};
	int idx;

	idx=Slot[1].idx;
	if (idx == -1) {
		return;
	}

	if (bDirectDelete) {
		bDelete=TRUE;
	} else {
		bDelete=MessageBox(hWndMain,"�� ������ �����ұ��?","����",MB_YESNO)==IDYES;
	}
	if (bDelete==FALSE) {
		return;
	}

	// �ɼ� ������ ���� ǥ�ø� �Ѵ�.
	if (bMarkDelete) {
		FileList[idx].bMark = !FileList[idx].bMark;
		MovePicture(TRUE);
		return;
	}

	wsprintf(Path,"%s\\%s",NowPath,FileList[idx].Name);
	if (DeleteImageFile(Path)==FALSE) {
		return;
	}

	// ���� ��� ����
	memmove(&FileList[idx],&FileList[idx+1],sizeof(tag_File)*(ListNum-idx-1));
	ListNum--;

	// ���� �׸����� �̵�
	if (Slot[2].idx != -1) {
		while (Slot[2].pCB == NULL) Sleep(21);
		WaitForSingleObject(hMutex,INFINITE);
		delete Slot[1].pCB;
		// �� �̹����� ���������Ƿ� ���� �̹����� �ε����� ����
		Slot[2].idx--;
		Slot[1]=Slot[2];
		Slot[2].pCB=NULL;
		Slot[2].idx=GetNextIdx(Slot[1].idx);
		ReleaseMutex(hMutex);
	// ���� ������ �̹����̸� ó������ �ٽ� ��� ����
	} else {
		MoveFolder(NowPath);
	}
	InvalidateRect(hAlbum,NULL,FALSE);
	ChangeCaption();
}

void DeleteMarked()
{
	int i,num;
	TCHAR Mes[256];
	TCHAR Path[MAX_PATH];

	for (i=0,num=0;i<ListNum;i++) {
		if (FileList[i].bMark) num++;
	}

	if (num == 0) {
		MessageBox(hWndMain,"���� ��� ������ �ϳ��� �����ϴ�","�˸�",MB_OK);
		return;
	}

	wsprintf(Mes,"���� ��� ���� %d���� �ϰ� �����Ͻðڽ��ϱ�?",num);
	if (MessageBox(hWndMain,Mes,"����",MB_YESNO)==IDNO) {
		return;
	}

	for (i=0;i<ListNum;i++) {
		if (FileList[i].bMark) {
			memset(Path,0,MAX_PATH);
			wsprintf(Path,"%s\\%s",NowPath,FileList[i].Name);
			if (DeleteImageFile(Path)==FALSE) {
				break;
			}
		}
	}
	MoveFolder(NowPath);
}

BOOL DeleteImageFile(TCHAR *Path)
{
	SHFILEOPSTRUCT fos={0,};
	int Deleted;

	if (bRecycleDelete) {
		fos.hwnd=hWndMain;
		fos.wFunc=FO_DELETE;
		fos.pFrom=Path;
		fos.fFlags=FOF_NOCONFIRMATION | FOF_ALLOWUNDO;
		fos.lpszProgressTitle="���� ������";
		Deleted=(SHFileOperation(&fos)==0);
	} else {
		Deleted=DeleteFile(Path);
	}
	return Deleted;
}
