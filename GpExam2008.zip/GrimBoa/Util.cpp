#include <windows.h>
#include <shlobj.h>
#include <shlwapi.h>
#include "ShReg.h"
#include "Util.h"

int CALLBACK BrowseCallbackProc(HWND hwnd,UINT uMsg,LPARAM lParam,LPARAM lpData)
{
	switch (uMsg)
	{
	case BFFM_INITIALIZED:
		if (lpData != NULL) {
			SendMessage(hwnd,BFFM_SETSELECTION,TRUE,(LPARAM)lpData);
		}
		break;
	}
	return 0;
}

BOOL BrowseFolder(HWND hParent, LPCTSTR szTitle, LPCTSTR StartPath, TCHAR *szFolder)
{
	LPMALLOC pMalloc;
	LPITEMIDLIST pidl;
	BROWSEINFO bi;

	bi.hwndOwner = hParent;
	bi.pidlRoot = NULL;
	bi.pszDisplayName = NULL;
	bi.lpszTitle = szTitle ;
	bi.ulFlags = 0;
	bi.lpfn = BrowseCallbackProc;;
	bi.lParam = (LPARAM)StartPath;
						
	pidl = SHBrowseForFolder(&bi);

	if (pidl == NULL) {
		return FALSE;
	}
	SHGetPathFromIDList(pidl, szFolder);

	if (SHGetMalloc(&pMalloc) != NOERROR) {
		return FALSE;
	}
	pMalloc->Free(pidl);
	pMalloc->Release();
	return TRUE;
}

BOOL IsMatch(TCHAR *Path, TCHAR *Pattern)
{
	TCHAR Pat[MAX_PATH];
	TCHAR *t,*p;
	TCHAR Ext[_MAX_EXT];
	TCHAR Name[MAX_PATH];
	TCHAR *p1,*p2;
	BOOL bOther;

	_splitpath(Path,NULL,NULL,Name,Ext);
	lstrcat(Name,Ext);
	CharUpper(Name);

	t=Pattern;
	for (;;) {
		p=Pat;
		while (*t!=';' && *t!=0) {
			*p=*t;
			p++;
			t++;
		}
		*p=0;

		CharUpper(Pat);
		if (Pat[0]=='*' && Pat[1]=='.') {
			if (lstrcmpi(Pat+1,Ext)==0) {
				return TRUE;
			}
		}
		p1=Name;
		p2=Pat;
		for (;;) {
			if (*p2=='?') {
				p1++;
				p2++;
			} else if (*p2=='*') {
				p2++;
				while (*p1!=*p2 && *p1!=0) 
					p1++;
			} else {
				if (*p1!=*p2) {
					break;
				}
				p1++;
				p2++;
			}

			if (*p1==0 && *p2==0) {
				return TRUE;
			}
			if (*p1!=0 && *p2==0) {
				break;
			}
			if (*p1==0 && *p2!=0) {
				bOther=FALSE;
				while (*p2) {
					if (*p2!='.' && *p2!='*') {
						bOther=TRUE;
					}
					p2++;
				}
				if (bOther==FALSE) {
					return TRUE;
				}
				break;
			}
		}

		if (*t==0) {
			break;
		}
		t++;
	}
	return FALSE;
}

BOOL bContFIF=TRUE;
void FindInFiles(TCHAR *Path, TCHAR *Pattern, DWORD Flags, FIFCALLBACK pCallBack, LPVOID pCustom)
{
	TCHAR SrchPath[MAX_PATH];
	TCHAR szFinded[MAX_PATH];
	WIN32_FIND_DATA wfd;
	HANDLE hSrch;
	BOOL nResult=TRUE;
	
	lstrcpy(SrchPath, Path);
	if (SrchPath[lstrlen(SrchPath)-1] == '\\') {
		SrchPath[lstrlen(SrchPath)-1]=0;
	}
	lstrcat(SrchPath, "\\*.*");
	hSrch=FindFirstFile(SrchPath,&wfd);
	if (hSrch == INVALID_HANDLE_VALUE) {
		return;
	}
	
	while (nResult) {
		wsprintf(szFinded,"%s\\%s",Path,wfd.cFileName);
		if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
			if (lstrcmp(wfd.cFileName,".") && lstrcmp(wfd.cFileName,"..")) {
				if (
					((wfd.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)==0 || (Flags & FIF_INCHID))
					&& ((Flags & FIF_DIRFILTER)==0 || IsMatch(szFinded, Pattern))
					) {
					pCallBack(szFinded,wfd.dwFileAttributes,pCustom);
				}
				if (Flags & FIF_DEEP) {
					FindInFiles(szFinded,Pattern,Flags,pCallBack,pCustom);
				}
			}
		} else {
			if (((wfd.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)==0 || (Flags & FIF_INCHID)) 
				&& IsMatch(szFinded, Pattern)) {
				pCallBack(szFinded,wfd.dwFileAttributes,pCustom);
			}
		}
		if (bContFIF==FALSE)
			break;
		nResult=FindNextFile(hSrch,&wfd);
	}
	FindClose(hSrch);
}

void SavePosition(HWND hWnd, TCHAR *Key)
{
	WINDOWPLACEMENT wndpl;

	wndpl.length=sizeof(WINDOWPLACEMENT);
	GetWindowPlacement(hWnd,&wndpl);
	if (wndpl.showCmd == SW_SHOWMAXIMIZED) {
		SHRegWriteInt(SHCU,Key,"Max", 1);
	} else {
		SHRegWriteInt(SHCU,Key,"Max", 0);
	}

	SHRegWriteInt(SHCU,Key,"left", wndpl.rcNormalPosition.left);
	SHRegWriteInt(SHCU,Key,"top", wndpl.rcNormalPosition.top);
	SHRegWriteInt(SHCU,Key,"right", wndpl.rcNormalPosition.right);
	SHRegWriteInt(SHCU,Key,"bottom",wndpl.rcNormalPosition.bottom);
}

void LoadPosition(HWND hWnd, TCHAR *Key, RECT *Def/*=NULL*/)
{
	WINDOWPLACEMENT wndpl;
	RECT drt;

	if (Def==NULL) {
		SetRect(&drt,10,10,600,400);
	} else {
		CopyRect(&drt,Def);
	}
	wndpl.length=sizeof(WINDOWPLACEMENT);
	wndpl.flags=0;
	wndpl.rcNormalPosition.left=SHRegReadInt(SHCU,Key,"left",drt.left);
	wndpl.rcNormalPosition.top=SHRegReadInt(SHCU,Key,"top",drt.top);
	wndpl.rcNormalPosition.right=SHRegReadInt(SHCU,Key,"right",drt.right);
	wndpl.rcNormalPosition.bottom=SHRegReadInt(SHCU,Key,"bottom",drt.bottom);

	if (SHRegReadInt(SHCU,Key, "Max", 0) == 1) {
		wndpl.showCmd=SW_SHOWMAXIMIZED;
	} else {
		wndpl.showCmd=SW_RESTORE;
	}
	wndpl.ptMinPosition.x=wndpl.ptMinPosition.y=0;
	wndpl.ptMaxPosition.x=wndpl.ptMaxPosition.y=0;
	SetWindowPlacement(hWnd,&wndpl);
}

void MoveToParentCenter(HWND hWnd)
{
	RECT wrt,crt;
	HWND hParent;

	hParent=GetParent(hWnd);
	if (hParent == NULL) {
		return;
	}
	if (IsIconic(hParent)) {
		ShowWindow(hParent,SW_RESTORE);
	}

	GetWindowRect(hParent,&wrt);
	GetWindowRect(hWnd,&crt);
	SetWindowPos(hWnd,HWND_NOTOPMOST,wrt.left+(wrt.right-wrt.left)/2-(crt.right-crt.left)/2,
		wrt.top+(wrt.bottom-wrt.top)/2-(crt.bottom-crt.top)/2,0,0,SWP_NOSIZE);
}

// ext Ȯ���ڰ� RegName�� ����Ǿ� �ִ��� �����Ѵ�.
BOOL TestAssociate(LPCTSTR ext, LPCTSTR RegName)
{
	TCHAR OldProgID[MAX_PATH];
	TCHAR NewProgID[MAX_PATH];

	SHRegReadString(SHCR,ext,NULL,"",OldProgID,MAX_PATH);
	wsprintf(NewProgID,"%s%s",RegName,ext);
	return (lstrcmpi(OldProgID,NewProgID)==0);
}

// ext Ȯ���ڸ� exe ���� ���ϰ� �����Ѵ�. RegName�� ������Ʈ�� Ű, desc�� ����
void MakeAssociate(LPCTSTR ext, LPCTSTR RegName, LPCTSTR exe, LPCTSTR desc)
{
	TCHAR OldProgID[64];
	TCHAR OldDesc[64];
	TCHAR NewProgID[64];
	TCHAR NewDesc[64];
	TCHAR szKey[MAX_PATH];
	TCHAR Path[MAX_PATH];

	// ���� ID�� ������ �̸� ���� ���´�.
	SHRegReadString(SHCR,ext,NULL,"",OldProgID,64);
	SHRegReadString(SHCR,OldProgID,NULL,"",OldDesc,64);

	// �� ID�� ������ �ۼ��Ѵ�. ������ ������ ���� ������ ���Ѵ�.
	wsprintf(NewProgID,"%s%s",RegName,ext);
	lstrcpy(NewDesc,desc ? OldDesc:desc);

	// �� ID�� ���� ���ɿ� ���� ������Ʈ�� Ű�� �ۼ��Ѵ�.
	SHRegWriteString(SHCR,NewProgID,NULL,NewDesc);
	wsprintf(szKey,"%s\\shell\\open\\command",NewProgID);
	wsprintf(Path, "\"%s\" \"%%1\"",exe);
	SHRegWriteString(SHCR,szKey,NULL,Path);

	// ������ ����
	wsprintf(szKey,"%s\\DefaultIcon",NewProgID);
	wsprintf(Path, "\"%s\",0",exe);
	SHRegWriteString(SHCR,szKey,NULL,Path);

	// �� ID�� �����Ѵ�.
	SHRegWriteString(SHCR,ext,NULL,NewProgID);

	// ���� ID�� ������ ���´�. ��, �ߺ� ���������� �ʴ´�.
	if (lstrcmp(OldProgID, NewProgID)!=0) {
		wsprintf(szKey,"%sOld",RegName);
		SHRegWriteString(SHCR,NewProgID,szKey,OldProgID);
	}

	SHChangeNotify(SHCNE_ASSOCCHANGED,SHCNF_IDLIST,NULL,NULL);
}

// ext Ȯ���ڿ��� ������ �����Ѵ�.
void UnAssociate(LPCTSTR ext, LPCTSTR RegName)
{
	TCHAR OldProgID[64];
	TCHAR NewProgID[64];
	TCHAR szKey[MAX_PATH];

	if (TestAssociate(ext,RegName)) {
		wsprintf(NewProgID,"%s%s",RegName,ext);
		wsprintf(szKey,"%sOld",RegName);
		SHRegReadString(SHCR,NewProgID,szKey,"",OldProgID,64);
		SHRegWriteString(SHCR,ext,NULL,OldProgID);
		SHDeleteKey(SHCR,NewProgID);
		SHChangeNotify(SHCNE_ASSOCCHANGED,SHCNF_IDLIST,NULL,NULL);
	}
}

// Ȯ���ڿ� ����� ���� ������ ��θ� �����Ѵ�.
void ModifyAssociate(LPCTSTR ext, LPCTSTR RegName, LPCTSTR exe)
{
	TCHAR szKey[MAX_PATH];
	TCHAR Path[MAX_PATH];

	// ����Ǿ� ������ ��ο� �������� �����Ѵ�.
	if (TestAssociate(ext,RegName)) {
		wsprintf(szKey,"%s%s\\shell\\open\\command",RegName,ext);
		wsprintf(Path, "\"%s\" \"%%1\"",exe);
		SHRegWriteString(SHCR,szKey,NULL,Path);

		wsprintf(szKey,"%s%s\\DefaultIcon",RegName,ext);
		wsprintf(Path, "\"%s\",0",exe);
		SHRegWriteString(SHCR,szKey,NULL,Path);
	}
}
