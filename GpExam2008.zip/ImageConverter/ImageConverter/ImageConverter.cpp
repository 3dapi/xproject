#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("ImageConverter");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#include <tchar.h>
TCHAR BmpPath[MAX_PATH];
BOOL GetEncCLSID(WCHAR *mime, CLSID *pClsid)
{
	UINT num,size,i;
	ImageCodecInfo *arCod;
	BOOL bFound=FALSE;

	GetImageEncodersSize(&num,&size);
	arCod=(ImageCodecInfo *)malloc(size);
	GetImageEncoders(num,size,arCod);

	for (i=0;i<num;i++) {
		if(wcscmp(arCod[i].MimeType,mime)==0) {
			 *pClsid=arCod[i].Clsid;
			 bFound=TRUE;
			 break;
		}    
	}
	free(arCod);
	return bFound;
}

void OnPaint(HDC hdc)
{
	Graphics G(hdc);

	if (lstrlen(BmpPath) != 0) {
		Image I(BmpPath);
		G.DrawImage(&I,0,20);
	}
}

void PrintParaList(WCHAR *MimeType)
{
	HDC hdc;
	CLSID Clsid;
	UINT size,i;
	EncoderParameters *pPara;
	WCHAR ParaGuid[39];
	TCHAR str[128];
	int y=0;

	if (GetEncCLSID(MimeType,&Clsid) == FALSE) {
		return;
	}
	InvalidateRect(hWndMain,NULL,TRUE);
	UpdateWindow(hWndMain);
	hdc=GetDC(hWndMain);
	Bitmap *pB=new Bitmap(1,1);
	size=pB->GetEncoderParameterListSize(&Clsid);
	if (size == 0) {
		wsprintf(str, TEXT("MIME : %s, �Ķ���� ����"), MimeType);
		TextOut(hdc,0,y+=20,str,lstrlen(str));
	} else {
		pPara=(EncoderParameters *)malloc(size);
		pB->GetEncoderParameterList(&Clsid,size,pPara);

		wsprintf(str, TEXT("MIME : %s, �Ķ���� ���� : %d"), MimeType, pPara->Count);
		TextOut(hdc,0,y+=20,str,lstrlen(str));
		for (i=0;i<pPara->Count;i++) {
			StringFromGUID2(pPara->Parameter[i].Guid,ParaGuid,39);
			wsprintf(str,TEXT("GUID:%s, Ÿ��:%d, ����:%d"),ParaGuid,
				pPara->Parameter[i].Type,pPara->Parameter[i].NumberOfValues);
			TextOut(hdc,0,y+=20,str,lstrlen(str));
		}

		free(pPara);
	}
	delete(pB);
	ReleaseDC(hWndMain,hdc);
}

void SavePng(TCHAR *Path)
{
	TCHAR NewName[MAX_PATH];
	Image *pI;
	CLSID Clsid;
	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];

	pI=Image::FromFile(Path);
	GetEncCLSID(L"image/png",&Clsid);
	_tsplitpath(Path,drive,dir,fname,ext);
	wsprintf(NewName,TEXT("%s%s%s.png"),drive,dir,fname);
	pI->Save(NewName,&Clsid,NULL);
	delete pI;
}

void SaveJpg(TCHAR *Path,ULONG Quality)
{
	TCHAR NewName[MAX_PATH];
	Image *pI;
	CLSID Clsid;
	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];
	EncoderParameters Para;

	pI=Image::FromFile(Path);
	GetEncCLSID(L"image/jpeg",&Clsid);
	_tsplitpath(Path,drive,dir,fname,ext);
	wsprintf(NewName,TEXT("%s%s%s_Q_%03d.jpg"),drive,dir,fname,Quality);
	Para.Count=1;
	Para.Parameter[0].Guid=EncoderQuality;
	Para.Parameter[0].Type=EncoderParameterValueTypeLong;
	Para.Parameter[0].NumberOfValues=1;
	Para.Parameter[0].Value=&Quality;

	pI->Save(NewName,&Clsid,&Para);
	delete pI;
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	TCHAR *Mes=TEXT("B:��Ʈ�� �б�, P:PNG�� ����, J:Jpeg�� ����, 1~5:�Ķ���� ��� ���");
	OPENFILENAME OFN;
	TCHAR lpstrFile[MAX_PATH]=TEXT("");

	switch(iMessage) {
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_KEYDOWN:
		switch (wParam) {
		case TEXT('B'):
			memset(&OFN, 0, sizeof(OPENFILENAME));
			OFN.lStructSize = sizeof(OPENFILENAME);
			OFN.hwndOwner=hWnd;
			OFN.lpstrFilter=TEXT("��Ʈ�� ����(*.BMP)\0*.BMP\0");
			OFN.lpstrFile=lpstrFile;
			OFN.nMaxFile=MAX_PATH;
			if (GetOpenFileName(&OFN)!=0) {
				lstrcpy(BmpPath,lpstrFile);
				InvalidateRect(hWnd,NULL,TRUE);
			}
			break;
		case TEXT('P'):
			if (lstrlen(BmpPath) != 0) {
				SavePng(BmpPath);
				MessageBox(hWnd,TEXT("PNG �������� �����߽��ϴ�"),TEXT("�˸�"),MB_OK);
			}
			break;
		case TEXT('J'):
			if (lstrlen(BmpPath) != 0) {
				SaveJpg(BmpPath,0);
				SaveJpg(BmpPath,5);
				SaveJpg(BmpPath,10);
				SaveJpg(BmpPath,50);
				SaveJpg(BmpPath,100);
				MessageBox(hWnd,TEXT("JPG �������� �����߽��ϴ�"),TEXT("�˸�"),MB_OK);
			}
			break;
		case TEXT('1'):
			PrintParaList(TEXT("image/jpeg"));
			break;
		case TEXT('2'):
			PrintParaList(TEXT("image/png"));
			break;
		case TEXT('3'):
			PrintParaList(TEXT("image/bmp"));
			break;
		case TEXT('4'):
			PrintParaList(TEXT("image/gif"));
			break;
		case TEXT('5'):
			PrintParaList(TEXT("image/tiff"));
			break;
		}
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		TextOut(hdc,0,0,Mes,lstrlen(Mes));
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}
