#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("Composite");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#include <math.h>
TCHAR Mode=TEXT('1');
void OnPaint(HDC hdc)
{
	Graphics G(hdc);
	Matrix M;

	if (Mode == TEXT('1')) {
		// Ȯ�� �� �̵�
		G.TranslateTransform(50,50);
		G.ScaleTransform(2,2);
	} else if (Mode == TEXT('2')) {
		// Ȯ�� �� �̵� - ���
		M.SetElements(2,0,0,2,50,50);
		G.SetTransform(&M);
	} else if (Mode == TEXT('3')) {
		// �̵� �� Ȯ��
		G.ScaleTransform(2,2);
		G.TranslateTransform(50,50);
	} else if (Mode == TEXT('4')) {
		// �̵� �� Ȯ�� - ���
		M.SetElements(2,0,0,2,100,100);
		G.SetTransform(&M);
	} else if (Mode == TEXT('5')) {
		// ���� ���� 30�� ȸ��
		M.RotateAt(-30,PointF(80,40));
		G.SetTransform(&M);
	} else if (Mode == TEXT('6')) {
		// 30�� ȸ��
		M.Rotate(-30);
		G.SetTransform(&M);
	} else if (Mode == TEXT('7')) {
		// ���� ���� 30�� ȸ�� - ������ ���� ��ȯ
		G.TranslateTransform(80,40);
		G.RotateTransform(-30);	
		G.TranslateTransform(-80,-40);
	} else if (Mode == TEXT('8')) {
		// ���� ���� 30�� ȸ�� - ���
		double rad=-30*3.14/180;
		M.SetElements((REAL)cos(rad),(REAL)sin(rad),-(REAL)sin(rad),(REAL)cos(rad),
			-80*(REAL)cos(rad)+40*(REAL)sin(rad)+80,
			-80*(REAL)sin(rad)-40*(REAL)cos(rad)+40);
		G.SetTransform(&M);
	}
	
	G.DrawEllipse(&Pen(Color(0,0,0),3),10,10,140,60);
	Font F(L"����",18,FontStyleRegular,UnitPoint);
	G.DrawString(L"���� ��ȯ",-1,&F,PointF(20,30),&SolidBrush(Color(0,0,0)));
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_KEYDOWN:
		Mode=(TCHAR)wParam;
		InvalidateRect(hWnd,NULL,TRUE);
		return 0;
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}