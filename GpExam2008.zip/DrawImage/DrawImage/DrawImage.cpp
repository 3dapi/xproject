#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("DrawImage");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#include "resource.h"
TCHAR Mode=TEXT('1');
InterpolationMode imode=InterpolationModeDefault;
void OnPaint(HDC hdc)
{
	Graphics G(hdc);

	if (Mode == TEXT('1')) {
		// �����ڷ� �б�
		Image I(L"����.jpg");
		// ���� ó��
		if (I.GetLastStatus() != Ok) {
			MessageBox(hWndMain,TEXT("�̹��� ������ ���� �� �����ϴ�."),
				TEXT("����"),MB_OK);
			return;
		}

		G.DrawImage(&I,0,0);
	} else if (Mode == TEXT('2')) {
		// FromFile ���� �Լ��� �б�
		Image *pI;
		pI=Image::FromFile(L"����.jpg");

		G.DrawImage(pI,0,0);
		delete pI;
	} else if (Mode == TEXT('3')) {
		// ���ҽ����� �б�
		HRSRC hResource = FindResource(g_hInst, MAKEINTRESOURCE(IDR_JPG1),
			TEXT("JPG"));
		if (!hResource)	return;

		DWORD imageSize = SizeofResource(g_hInst, hResource);
		HGLOBAL hGlobal = LoadResource(g_hInst, hResource);
		LPVOID pData = LockResource(hGlobal);

		HGLOBAL hBuffer = GlobalAlloc(GMEM_MOVEABLE,imageSize);
		LPVOID pBuffer = GlobalLock(hBuffer);
		CopyMemory(pBuffer,pData,imageSize);
		GlobalUnlock(hBuffer);

		IStream *pStream;
		HRESULT hr=CreateStreamOnHGlobal(hBuffer,TRUE,&pStream);

		Image I(pStream);
		pStream->Release();
		if (I.GetLastStatus() != Ok) return;

		G.DrawImage(&I,0,0);
	} else if (Mode == TEXT('4')) {
		// �����ϸ� �����ϱ�
		Image I(L"�ڽ���.jpg");

		G.DrawImage(&I,0,0);
		G.DrawImage(&I,300,0,I.GetWidth(),I.GetHeight());
	} else if (Mode == TEXT('5')) {
		// Ȯ�� �� ���
		Image I(L"���չ�.jpg");

		G.DrawImage(&I,0,0,I.GetWidth()*2, I.GetHeight()*2);
		G.DrawImage(&I,650,0,I.GetWidth()/2, I.GetHeight()/2);
	} else if (Mode == TEXT('6')) {
		// ���� ��� ����
		Image I(L"���չ�.jpg");

		G.SetInterpolationMode(imode);
		G.DrawImage(&I,0,0,I.GetWidth()*2, I.GetHeight()*2);
		G.DrawImage(&I,I.GetWidth()*2+10,0,I.GetWidth()/2, I.GetHeight()/2);
	} else if (Mode == TEXT('7')) {
		// ���� �纯���� ����ϱ�
		Image I(L"���չ�.jpg");
		Point pts[]={Point(10,10),Point(300,50),Point(100,300)};

		G.DrawImage(&I,pts,3);
	} else if (Mode == TEXT('8')) {
		// �̹����� �Ϻκи� ���
		Image I(L"ȣ������.jpg");

		G.DrawImage(&I,0,0,150,40,220,300,UnitPixel);
	} else if (Mode == TEXT('9')) {
		// �̹����� �Ϻκи� ��� ���
		Image I(L"ȣ������.jpg");

		G.DrawImage(&I,Rect(0,0,110,150),150,40,220,300,UnitPixel);
	} else if (Mode == TEXT('A')) {
		// ���� �纯���� �Ϻθ� ����ϱ�
		Image I(L"ȣ������.jpg");
		Point pts[]={Point(10,10),Point(300,50),Point(100,300)};

		G.DrawImage(&I,pts,3,150,40,220,300,UnitPixel);
	} else if (Mode == TEXT('B')) {
		// ������ ���
		HICON hIcon;
		hIcon=LoadIcon(NULL,IDI_EXCLAMATION);
		Bitmap B(hIcon);

		G.DrawImage(&B,10,10);
	} else if (Mode == TEXT('C')) {
		// ���� ���۸�
		Bitmap B(100,100,&G);
		Graphics G2(&B);
		Pen P(Color(0,0,0),3);

		G2.DrawEllipse(&P,10,10,80,80);
		G.DrawImage(&B,0,0);
	} else if (Mode == TEXT('D')) {
		// ĳ�� ��Ʈ��
		Bitmap B(L"����.jpg");
		CachedBitmap CB(&B,&G);

		G.DrawCachedBitmap(&CB,0,0);
	} else if (Mode == TEXT('E')) {
		// ��Ÿ ���� ���
		Image I(L"testenh.emf");	

		G.DrawImage(&I,10,10);
	} else if (Mode == TEXT('F')) {
		// ��Ÿ ���� ��� �� ���
		Metafile M(L"GpMeta.emf",hdc);
		Graphics *pG=new Graphics(&M);
		Pen P(Color(255,0,0),5);
		Pen P2(Color(0,0,0));

		pG->DrawEllipse(&P,10,10,100,100);
		pG->DrawRectangle(&P2,30,30,50,50);
		delete pG;

		Metafile M2(L"GpMeta.emf");
		G.DrawImage(&M2,10,10);	
	} else if (Mode == TEXT('G')) {
		// �̹��� ������Ƽ �б�
		Image I(L"����.jpg");
		UINT size,count,i,y=0;
		PropertyItem *arPro;
		TCHAR str[1024];

		I.GetPropertySize(&size,&count);
		arPro=(PropertyItem *)malloc(size);
		I.GetAllPropertyItems(size,count,arPro);

		for (i=0;i<count;i++) {
			switch (arPro[i].id) {
			case PropertyTagImageTitle:
				wsprintf(str,TEXT("���� : %S"),(TCHAR *)arPro[i].value);
				break;
			case PropertyTagImageDescription:
				wsprintf(str,TEXT("���� : %S"),(TCHAR *)arPro[i].value);
				break;
			case PropertyTagCopyright:
				wsprintf(str,TEXT("���۱� : %S"),(TCHAR *)arPro[i].value);
				break;
			case PropertyTagEquipMake:
				wsprintf(str,TEXT("��� : %S"),(TCHAR *)arPro[i].value);
				break;
			case PropertyTagEquipModel:
				wsprintf(str,TEXT("�� : %S"),(TCHAR *)arPro[i].value);
				break;
			case PropertyTagXResolution:
				wsprintf(str,TEXT("���� �ػ� : %d"),*(LONG *)arPro[i].value);
				break;
			case PropertyTagYResolution:
				wsprintf(str,TEXT("���� �ػ� : %d"),*(LONG *)arPro[i].value);
				break;
			case PropertyTagSoftwareUsed:
				wsprintf(str,TEXT("����� ����Ʈ���� : %S"),(TCHAR *)arPro[i].value);
				break;
			case PropertyTagDateTime:
				wsprintf(str,TEXT("��¥ : %S"),(TCHAR *)arPro[i].value);
				break;
			default:
				continue;
			}
			TextOut(hdc,0,y*20,str,lstrlen(str));
			y++;
		}

		free(arPro);
	}
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_KEYDOWN:
		if (Mode == TEXT('6')) {
			switch (wParam) {
			case 'I':
				if (imode == InterpolationModeHighQualityBicubic) {
					imode=InterpolationModeDefault;
				} else {
					imode=(InterpolationMode)(imode+1);
				}
				InvalidateRect(hWnd,NULL,FALSE);
				return 0;
			}
		}
		Mode=(TCHAR)wParam;
		InvalidateRect(hWnd,NULL,TRUE);
		return 0;
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}