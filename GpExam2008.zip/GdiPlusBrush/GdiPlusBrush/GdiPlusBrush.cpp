#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("GdiPlusBrush");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

TCHAR Mode=TEXT('1');
REAL angle=0;
BOOL bScale=TRUE;
void OnPaint(HDC hdc)
{
	Graphics G(hdc);
	
	if (Mode == TEXT('1')) {
		// �ܻ� �귯��
		SolidBrush S(Color(0,255,0));
		Pen P(Color(255,0,0),3);
		Rect R(10,10,300,150);

		G.FillEllipse(&S,R);
		G.DrawEllipse(&P,R);
	} else if (Mode == TEXT('2')) {
		// ��ġ �귯��
		HatchBrush *pH;
		int Hatch=HatchStyleMin;
		int x,y;

		for (y=0;;y++) {
			for (x=0;x<8;x++) {
				pH=new HatchBrush((HatchStyle)Hatch,Color(0,0,0),Color(255,255,255));
				G.FillRectangle(pH,x*80+10,y*50+10,70,40);
				delete pH;
				Hatch++;
				if (Hatch == HatchStyleMax) return;
			}
		}
	} else if (Mode == TEXT('3')) {
		// ���� �׷����Ʈ �귯��
		LinearGradientBrush LGB(Point(0,0),Point(100,0),Color(0,0,255),Color(0,0,0));

		G.FillRectangle(&LGB,0,0,100,100);
		G.FillRectangle(&LGB,10,110,350,100);
	} else if (Mode == TEXT('4')) {
		// �񽺵��� ���� �׷����Ʈ �귯��
		LinearGradientBrush LGB(Point(200,100),Point(400,200),Color(0,0,255),Color(255,255,255));

		G.FillRectangle(&LGB,0,0,600,300);
	} else if (Mode == TEXT('5')) {
		// ������ �����ϴ� �׷����Ʈ �귯��
		LinearGradientBrush LGB1(Rect(0,0,100,100),Color(0,0,0),Color(255,255,255),
			LinearGradientModeHorizontal);
		LinearGradientBrush LGB2(Rect(100,0,100,100),Color(0,0,0),Color(255,255,255),
			LinearGradientModeVertical);
		LinearGradientBrush LGB3(Rect(200,0,100,100),Color(0,0,0),Color(255,255,255),
			LinearGradientModeForwardDiagonal);
		LinearGradientBrush LGB4(Rect(300,0,100,100),Color(0,0,0),Color(255,255,255),
			LinearGradientModeBackwardDiagonal);

		G.FillRectangle(&LGB1,0,0,100,100);
		G.FillRectangle(&LGB2,100,0,100,100);
		G.FillRectangle(&LGB3,200,0,100,100);
		G.FillRectangle(&LGB4,300,0,100,100);
	} else if (Mode == TEXT('6')) {
		// ������ �����ϴ� �귯��
		LinearGradientBrush LGB(Rect(0,0,200,200),Color(0,0,0),Color(255,255,255),
			angle,bScale);

		G.FillRectangle(&LGB,0,0,200,200);
	} else if (Mode == TEXT('7')) {
		// �ؽ�ó �귯��
		Image I(L"Pride200.jpg");
		TextureBrush TB(&I,WrapModeTile);
		//TextureBrush TB(&I,WrapModeTileFlipX);

		RECT crt;
		GetClientRect(hWndMain,&crt);
		G.FillRectangle(&TB,0,0,crt.right,crt.bottom);
	} else if (Mode == TEXT('8')) {
		// �ؽ�ó �귯��
		Image I(L"Pride200.jpg");
		TextureBrush TB(&I,WrapModeTileFlipX);

		RECT crt;
		GetClientRect(hWndMain,&crt);
		G.FillRectangle(&TB,0,0,crt.right,crt.bottom);
	}
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_KEYDOWN:
		if (Mode == TEXT('6')) {
			switch (wParam) {
			case VK_UP:
				angle += 5;
				InvalidateRect(hWnd,NULL,FALSE);
				return 0;
			case VK_DOWN:
				angle -= 5;
				InvalidateRect(hWnd,NULL,FALSE);
				return 0;
			case VK_SPACE:
				bScale = !bScale;
				InvalidateRect(hWnd,NULL,FALSE);
				return 0;
			}
		}
		Mode=(TCHAR)wParam;
		InvalidateRect(hWnd,NULL,TRUE);
		return 0;
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}