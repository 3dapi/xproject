#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("MeasureString");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

RectF MeasureString(Graphics &G,Font &F,LPCTSTR String,int Count)
{
	RectF layout(0,0,65536,65536);
	CharacterRange cr(0,Count == -1 ? lstrlen(String):Count);
	StringFormat sf;
	sf.SetMeasurableCharacterRanges(1,&cr);
	Region rgn;
	G.MeasureCharacterRanges(String,Count,&F,layout,&sf,1,&rgn);
	RectF rt;
	rgn.GetBounds(&rt,&G);
	return rt;
}

TCHAR Mode=TEXT('1');
void OnPaint(HDC hdc)
{
	Graphics G(hdc);

	if (Mode == TEXT('1')) {
		//�ٸ� ��Ʈ �����ؼ� ����ϱ�
		REAL x=0;
		const REAL FontSize=32;
		TCHAR *San[]={L"��λ�",L"�Ѷ��",L"�ݰ���"};
		RectF bound;

		Font F1(L"����",FontSize,FontStyleRegular,UnitPoint);
		G.DrawString(San[0],-1,&F1,PointF(x,0),&SolidBrush(Color(0,0,255)));
		G.MeasureString(San[0],-1,&F1,PointF(x,0),&bound);
		x += (int)bound.Width;

		Font F2(L"�ü�",FontSize,FontStyleRegular,UnitPoint);
		G.DrawString(San[1],-1,&F2,PointF(x,0),&SolidBrush(Color(255,0,0)));
		G.MeasureString(San[1],-1,&F2,PointF(x,0),&bound);
		x += (int)bound.Width;

		Font F3(L"����",FontSize,FontStyleRegular,UnitPoint);
		G.DrawString(San[2],-1,&F3,PointF(x,0),&SolidBrush(Color(0,255,0)));
		G.MeasureString(San[2],-1,&F3,PointF(x,0),&bound);
		x += (int)bound.Width;
	} else if (Mode == TEXT('2')) {
		// ���ڿ��� �� ����
		TCHAR *Hangul=L"�ѱ� ���ڿ�";
		TCHAR szWidth[128];
		RectF bound;

		// GDI+
		Font F(L"����",20,FontStyleRegular,UnitPixel);
		SolidBrush B(Color(0,0,0));
		G.DrawString(Hangul,-1,&F,PointF(0,00),&B);
		G.MeasureString(Hangul,-1,&F,PointF(0,0),&bound);
		wsprintf(szWidth,TEXT("��:%d, ����:%d"),(int)bound.Width,(int)bound.Height);
		G.DrawString(szWidth,-1,&F,PointF(200,0),&B);

		// GDI
		HFONT hFont,hOldFont;
		hFont=CreateFont(20,0,0,0,0,0,0,0,HANGUL_CHARSET,3,2,1,
			VARIABLE_PITCH | FF_MODERN,TEXT("����"));
		hOldFont=(HFONT)SelectObject(hdc,hFont);
		TextOut(hdc,0,50,Hangul,lstrlen(Hangul));
		SIZE sz;
		GetTextExtentPoint32(hdc,Hangul,lstrlen(Hangul),&sz);
		wsprintf(szWidth,TEXT("��:%d, ����:%d"),sz.cx,sz.cy);
		TextOut(hdc,200,50,szWidth,lstrlen(szWidth));
		DeleteObject(SelectObject(hdc,hOldFont));
	} else if (Mode == TEXT('3')) {
		// ������ ��Ȯ�� ��ġ ���ϱ�
		TCHAR *korea=L"�Ƹ��ٿ� �ݼ����� �츮���� ���ѹα�";
		RectF layout(0,0,200,200);

		CharacterRange arRange[2]={ CharacterRange(2,4), CharacterRange(12,5) };
		StringFormat sf;
		sf.SetMeasurableCharacterRanges(2,arRange);
		Region *arRgn = new Region[2];

		Font Gulim(L"����",20,FontStyleRegular,UnitPoint);
		G.MeasureCharacterRanges(korea,-1,&Gulim,layout,&sf,2,arRgn);
		G.FillRegion(&SolidBrush(Color(0,0,255)),&arRgn[0]);
		G.FillRegion(&SolidBrush(Color(0,0,255)),&arRgn[1]);
		G.DrawRectangle(&Pen(Color(0,0,0)),layout);
		G.DrawString(korea,-1,&Gulim,layout,&sf,&SolidBrush(Color(0,0,0)));
		delete [] arRgn;
	} else if (Mode == TEXT('4')) {
		// �ٸ� ��Ʈ �����ؼ� ����ϱ�
		REAL x=0;
		const REAL FontSize=32;
		TCHAR *San[]={L"��λ�",L"�Ѷ��",L"�ݰ���"};
		RectF bound;

		Font F1(L"����",FontSize,FontStyleRegular,UnitPoint);
		G.DrawString(San[0],-1,&F1,PointF(x,0),&SolidBrush(Color(0,0,255)));
		bound=MeasureString(G,F1,San[0],-1);
		x += (int)bound.Width;

		Font F2(L"�ü�",FontSize,FontStyleRegular,UnitPoint);
		G.DrawString(San[1],-1,&F2,PointF(x,0),&SolidBrush(Color(255,0,0)));
		bound=MeasureString(G,F1,San[1],-1);
		x += (int)bound.Width;

		Font F3(L"����",FontSize,FontStyleRegular,UnitPoint);
		G.DrawString(San[2],-1,&F3,PointF(x,0),&SolidBrush(Color(0,255,0)));
		bound=MeasureString(G,F1,San[2],-1);
		x += (int)bound.Width;
	} else if (Mode == TEXT('5')) {
		// �ϰ����� ���� ���ڰ��� �׽�Ʈ
		TCHAR AeKuk[]=
			TEXT("���ع��� ��λ��� ������ �⵵�� �ϴ����� �����ϻ� �츮���� ����.")
			TEXT("����ȭ ��õ�� ȭ�� ���� ���ѻ�� �������� ���� �����ϼ�");
		int i;
		Font F(L"����",10,FontStyleRegular,UnitPoint);
		SolidBrush B(Color(0,0,0));

		for (i=0;i<=lstrlen(AeKuk);i++) {
			G.FillRectangle(&SolidBrush(Color(255,255,255)),0,0,1024,50);
			G.DrawString(AeKuk,i,&F,PointF(0,0),&B);
			GdiFlush();
			Sleep(50);
		}
	}
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_KEYDOWN:
		Mode=(TCHAR)wParam;
		InvalidateRect(hWnd,NULL,TRUE);
		return 0;
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}