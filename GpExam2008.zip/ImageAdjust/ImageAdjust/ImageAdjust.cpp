#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("ImageAdjust");
#include "resource.h"

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=MAKEINTRESOURCE(IDR_MENU1);
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

Image *pImage=NULL;
void OnPaint(HDC hdc)
{
	Graphics G(hdc);

	if (pImage) {
		G.DrawImage(pImage,0,0,pImage->GetWidth(),pImage->GetHeight());
	}
}

void OpenFile()
{
	OPENFILENAME OFN;
	TCHAR lpstrFile[MAX_PATH]=TEXT("");

	memset(&OFN, 0, sizeof(OPENFILENAME));
	OFN.lStructSize = sizeof(OPENFILENAME);
	OFN.hwndOwner=hWndMain;
	OFN.lpstrFilter=TEXT("��� �׷��� ����\0*.bmp;*.jpg;*.gif;*.png\0��� ����(*.*)\0*.*\0");
	OFN.lpstrFile=lpstrFile;
	OFN.nMaxFile=MAX_PATH;
	if (GetOpenFileName(&OFN)!=0) {
		if (pImage) {
			delete pImage;
		}
		pImage=Image::FromFile(lpstrFile);
		InvalidateRect(hWndMain,NULL,TRUE);
	}
}

void Threshold(float value)
{
	Graphics *pG=Graphics::FromImage(pImage);
	ImageAttributes	IA;
	INT Width,Height;

	Width=pImage->GetWidth();
	Height=pImage->GetHeight();
	IA.SetThreshold(value,ColorAdjustTypeDefault);
	pG->DrawImage(pImage,Rect(0,0,Width,Height),	
		0,0,Width,Height,UnitPixel,&IA);
	delete pG;
}

void Gamma(float value)
{
	Graphics *pG=Graphics::FromImage(pImage);
	ImageAttributes	IA;
	INT Width,Height;

	Width=pImage->GetWidth();
	Height=pImage->GetHeight();
	IA.SetGamma(value,ColorAdjustTypeDefault);
	pG->DrawImage(pImage,Rect(0,0,Width,Height),	
		0,0,Width,Height,UnitPixel,&IA);
	delete pG;
}

void Lighten(float value)
{
	Graphics *pG=Graphics::FromImage(pImage);
	ImageAttributes	IA;
	INT Width,Height;
	ColorMatrix matrix = {
		1.0f,	0.0f,	0.0f,	0.0f,	0.0f,
		0.0f,	1.0f,	0.0f,	0.0f,	0.0f,
		0.0f,	0.0f,	1.0f,	0.0f,	0.0f,
		0.0f,	0.0f,	0.0f,	1.0f,	0.0f,
		value,	value,	value,	0.0f,	1.0f
	};

	Width=pImage->GetWidth();
	Height=pImage->GetHeight();
	IA.SetColorMatrix(&matrix,ColorMatrixFlagsDefault,ColorAdjustTypeBitmap);
	pG->DrawImage(pImage,Rect(0,0,Width,Height),	
		0,0,Width,Height,UnitPixel,&IA);
	delete pG;
}

void Negative()
{
	Graphics *pG=Graphics::FromImage(pImage);
	ImageAttributes	IA;
	INT Width,Height;
	ColorMatrix matrix = {
		-1.0f,	0.0f,	0.0f,	0.0f,	0.0f,
		0.0f,	-1.0f,	0.0f,	0.0f,	0.0f,
		0.0f,	0.0f,	-1.0f,	0.0f,	0.0f,
		0.0f,	0.0f,	0.0f,	1.0f,	0.0f,
		1.0f,	1.0f,	1.0f,	0.0f,	1.0f
	};

	Width=pImage->GetWidth();
	Height=pImage->GetHeight();
	IA.SetColorMatrix(&matrix,ColorMatrixFlagsDefault,ColorAdjustTypeBitmap);
	pG->DrawImage(pImage,Rect(0,0,Width,Height),	
		0,0,Width,Height,UnitPixel,&IA);
	delete pG;
}

void GrayScale()
{
	Graphics *pG=Graphics::FromImage(pImage);
	ImageAttributes	IA;
	INT Width,Height;
	ColorMatrix matrix = {
		0.299f,	0.299f,	0.299f,	0.0f,	0.0f,
		0.587f,	0.587f,	0.587f,	0.0f,	0.0f,
		0.114f,	0.114f,	0.114f,	0.0f,	0.0f,
		0.0f,	0.0f,	0.0f,	1.0f,	0.0f,
		0.0f,	0.0f,	0.0f,	0.0f,	1.0f
	};

	Width=pImage->GetWidth();
	Height=pImage->GetHeight();
	IA.SetColorMatrix(&matrix,ColorMatrixFlagsDefault,ColorAdjustTypeBitmap);
	pG->DrawImage(pImage,Rect(0,0,Width,Height),	
		0,0,Width,Height,UnitPixel,&IA);
	delete pG;
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_COMMAND:
		switch (wParam) {
		case IDM_FILE_OPEN:
			OpenFile();
			break;
		case IDM_IMAGE_HORZFLIP:
			if (pImage) {
				pImage->RotateFlip(RotateNoneFlipX);
				InvalidateRect(hWnd,NULL,FALSE);
			}
			break;
		case IDM_IMAGE_VERTFLIP:
			if (pImage) {
				pImage->RotateFlip(RotateNoneFlipY);
				InvalidateRect(hWnd,NULL,FALSE);
			}
			break;
		case IDM_IMAGE_LEFTROTATE:
			if (pImage) {
				pImage->RotateFlip(Rotate270FlipNone);
				InvalidateRect(hWnd,NULL,TRUE);
			}
			break;
		case IDM_IMAGE_RIGHTROTATE:
			if (pImage) {
				pImage->RotateFlip(Rotate90FlipNone);
				InvalidateRect(hWnd,NULL,TRUE);
			}
			break;
		case IDM_IMAGE_180ROTATE:
			if (pImage) {
				pImage->RotateFlip(Rotate180FlipNone);
				InvalidateRect(hWnd,NULL,TRUE);
			}
			break;
		case IDM_IMAGE_THRESHOLD:
			if (pImage) {
				Threshold(0.5f);
				InvalidateRect(hWnd,NULL,TRUE);
			}
			break;
		case IDM_IMAGE_GAMMA:
			if (pImage) {
				Gamma(0.5f);
				InvalidateRect(hWnd,NULL,TRUE);
			}
			break;
		case IDM_IMAGE_LIGHT:
			if (pImage) {
				Lighten(0.1f);
				InvalidateRect(hWnd,NULL,FALSE);
			}
			break;
		case IDM_IMAGE_DARK:
			if (pImage) {
				Lighten(-0.1f);
				InvalidateRect(hWnd,NULL,FALSE);
			}
			break;
		case IDM_IMAGE_NEGATIVE:
			if (pImage) {
				Negative();
				InvalidateRect(hWnd,NULL,FALSE);
			}
			break;
		case IDM_IMAGE_GRAYSCALE:
			if (pImage) {
				GrayScale();
				InvalidateRect(hWnd,NULL,FALSE);
			}
			break;
		}
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		if (pImage) {
			delete pImage;
		}
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}
