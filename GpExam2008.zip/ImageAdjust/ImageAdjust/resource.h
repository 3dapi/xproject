//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ImageAdjust.rc
//
#define IDR_MENU1                       101
#define IDM_FILE_OPEN                   40001
#define IDM_IMAGE_HORZFLIP              40002
#define IDM_IMAGE_VERTFLIP              40003
#define IDM_IMAGE_LEFTROTATE            40004
#define IDM_IMAGE_RIGHTROTATE           40005
#define IDM_IMAGE_LIGHT                 40006
#define IDM_IMAGE_DARK                  40007
#define IDM_IMAGE_NEGATIVE              40008
#define IDM_IMAGE_GRAYSCALE             40009
#define IDM_IMAGE_180ROTATE             40010
#define IDM_IMAGE_GAMMA                 40011
#define IDM_IMAGE_THRESHOLD             40012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
