#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("GdiPlusDraw");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#include <tchar.h>
float tension=0.0;
TCHAR Mode=TEXT('1');
void OnPaint(HDC hdc)
{
	Graphics G(hdc);

	if (Mode == TEXT('1')) {
		// ���� �׸���
		Pen P(Color(0,0,0));

		G.DrawLine(&P,10,10,300,100);
		//G.DrawLine(&P,Point(10,10),Point(300,100));
	} else if (Mode == TEXT('2')) {
		// �ٰ��� �׸���
		Pen P(Color(0,0,0));
		Point pts[]={Point(100,10),Point(10,150),Point(190,150),Point(100,10)};

		G.DrawLines(&P,pts,sizeof(pts)/sizeof(pts[0]));
	} else if (Mode == TEXT('3')) {
		// �簢��, Ÿ�� �׸���
		Pen P(Color(255,0,0),5);
		SolidBrush S(Color(0,255,0));

		G.DrawEllipse(&P,10,10,90,90);
		G.DrawRectangle(&P,110,10,90,90);
		G.FillEllipse(&S,10,110,90,90);
		G.FillRectangle(&S,110,110,90,90);
	} else if (Mode == TEXT('4')) {
		// ���� ���� ������ ����
		G.DrawRectangle(&Pen(Color(0,0,0)),10,10,90,90);
		Rectangle(hdc,110,10,200,100);
		Rectangle(hdc,10,110,100,200);

		int i;
		for (i=0;i<=300;i+=50) {
			G.DrawRectangle(&Pen(Color(0,0,0)),i,210,50,50);
			Rectangle(hdc,i,270,i+50,320);
		}
	} else if (Mode == TEXT('5')) {
		// �ٰ��� �׸���
		Pen P(Color(0,0,255),2);
		SolidBrush S(Color(200,200,200));
		Point pts[]={Point(292,6),Point(331,45),Point(307,45),Point(269,77),
			Point(274,111),Point(251,116),Point(207,149),Point(165,155),
			Point(161,190),Point(201,206),Point(239,270),Point(258,287),
			Point(257,306),Point(249,313),Point(251,335),Point(263,333),
			Point(252,364),Point(231,380),Point(203,378),Point(201,392),
			Point(181,391),Point(157,389),Point(143,404),Point(117,402),
			Point(108,416),Point(95,403),Point(108,393),Point(96,378),
			Point(121,341),Point(109,302),Point(96,303),Point(95,292),
			Point(114,285),Point(132,292),Point(121,267),Point(114,243),
			Point(74,231),Point(72,251),Point(26,231),Point(70,205),
			Point(51,198),Point(71,166),Point(13,142),Point(90,103),
			Point(132,73),Point(151,56),Point(161,71),Point(202,79),
			Point(211,66),Point(206,51),Point(241,49),Point(266,30),
			Point(282,26),Point(283,7)};

		G.FillPolygon(&S,pts,sizeof(pts)/sizeof(pts[0]));
		G.DrawPolygon(&P,pts,sizeof(pts)/sizeof(pts[0]));
	} else if (Mode == TEXT('6')) {
		// ��ȣ
		Pen P(Color(0,0,0));
		SolidBrush S(Color(128,128,128));

		G.DrawArc(&P,10,10,90,90,15.0f,120.0f);
		G.DrawPie(&P,110,10,90,90,-15.0f,45.0f);
		G.FillPie(&S,10,110,90,90,-15.0f,45.0f);
	} else if (Mode == TEXT('7')) {
		// ī��� �
		Point pts[]={Point(10,100),Point(50,10),Point(100,150),Point(200,100)};
		Pen P(Color(0,0,0));

		G.DrawCurve(&P,pts,4,tension);
		TCHAR str[128];
		_stprintf_s(str,128,TEXT("��� : %.1f"),tension);
		TextOut(hdc,10,200,str,lstrlen(str));
	} else if (Mode == TEXT('8')) {
		// ������ �
		Pen P(Color(0,0,0));

		G.DrawBezier(&P,Point(10,150), Point(200,0), Point(100,400),Point(400,150));
	}
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch(iMessage) {
	case WM_KEYDOWN:
		if (Mode == TEXT('7')) {
			switch (wParam) {
			case VK_UP:
				tension += 0.1f;
				InvalidateRect(hWnd,NULL,TRUE);
				return 0;
			case VK_DOWN:
				tension -= 0.1f;
				InvalidateRect(hWnd,NULL,TRUE);
				return 0;
			}
		}
		Mode=(TCHAR)wParam;
		InvalidateRect(hWnd,NULL,TRUE);
		return 0;
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		OnPaint(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}
