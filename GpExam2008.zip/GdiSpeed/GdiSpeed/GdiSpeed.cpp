#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("GdiSpeed");

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")
class CGdiPlusStarter
{
private:
	ULONG_PTR m_gpToken;

public:
	bool m_bSuccess;
	CGdiPlusStarter() {
		GdiplusStartupInput gpsi;
		m_bSuccess=(GdiplusStartup(&m_gpToken,&gpsi,NULL) == Ok);
	}
	~CGdiPlusStarter() {
		GdiplusShutdown(m_gpToken);
	}
};
CGdiPlusStarter g_gps;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	if (g_gps.m_bSuccess == FALSE) {
		MessageBox(NULL,TEXT("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."),
			TEXT("�˸�"),MB_OK);
		return 0;
	}

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#define random(n) (rand()%n)
void SpeedTestGdi()
{
	HDC hdc;
	HBRUSH hBrush,hOldBrush;
	int i;
	int x,y,w,h;

	hdc=GetDC(hWndMain);
	SelectObject(hdc,GetStockObject(NULL_PEN));
	for (i=0;i<10000;i++) {
		hBrush=CreateSolidBrush(RGB(random(256),random(256),random(256)));
		hOldBrush=(HBRUSH)SelectObject(hdc,hBrush);
		x=random(640);
		y=random(480);
		w=random(150)+50;
		h=random(150)+50;
		Ellipse(hdc,x,y,x+w,y+h);
		DeleteObject(SelectObject(hdc,hOldBrush));
	}
	ReleaseDC(hWndMain,hdc);
}

void SpeedTestGdiPlus()
{
	Graphics G(hWndMain);
	SolidBrush S(Color(0,0,0));
	int i;
	int x,y,w,h;

	for (i=0;i<10000;i++) {
		S.SetColor(Color(random(256),random(256),random(256)));
		x=random(640);
		y=random(480);
		w=random(150)+50;
		h=random(150)+50;
		G.FillEllipse(&S,x,y,w,h);
	}
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	DWORD st;
	TCHAR str[128];
	TCHAR *Mes=TEXT("���� Ŭ�� : GDI �׸���, ������ Ŭ�� : GDI+ �׸���");

	switch(iMessage) {
	case WM_CREATE:
		hWndMain=hWnd;
		return 0;
	case WM_LBUTTONDOWN:
		st=GetTickCount();
		SpeedTestGdi();
		wsprintf(str,TEXT("�ҿ� �ð� = %dƽ"),GetTickCount()-st);
		SetWindowText(hWnd,str);
		return 0;
	case WM_RBUTTONDOWN:
		st=GetTickCount();
		SpeedTestGdiPlus();
		wsprintf(str,TEXT("�ҿ� �ð� = %dƽ"),GetTickCount()-st);
		SetWindowText(hWnd,str);
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);
		TextOut(hdc,10,700,Mes,lstrlen(Mes));
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}


